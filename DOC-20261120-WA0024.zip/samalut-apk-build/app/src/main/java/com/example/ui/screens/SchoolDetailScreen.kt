package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyLogEntry
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.ui.components.CompactTopBar
import com.example.ui.theme.*
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolDetailScreen(
    school: School?,
    teachers: List<Teacher>,
    incidents: List<SecurityIncident>,
    dailyLogs: List<DailyLogEntry>,
    onAddIncidentClick: (String) -> Unit,
    onTeacherClick: (Long) -> Unit,
    onIncidentClick: (Long) -> Unit,
    onAddDailyLog: (DailyLogEntry) -> Unit,
    trips: List<com.example.data.model.SchoolTripEntity> = emptyList(),
    adminConfig: com.example.data.preferences.AdminConfig = com.example.data.preferences.AdminConfig(),
    onAddTrip: (com.example.data.model.SchoolTripEntity) -> Unit = {},
    onDeleteTrip: (com.example.data.model.SchoolTripEntity) -> Unit = {},
    onUpdateSchool: ((School) -> Unit)? = null,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    var showAddLogDialog by remember { mutableStateOf(false) }
    var showAddTripDialog by remember { mutableStateOf(false) }
    var showSummary by remember { mutableStateOf(false) }
    var logNoteText by remember { mutableStateOf("") }
    var viewingAttachment by remember { mutableStateOf<String?>(null) }

    // Pickers
    val docPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (school != null && onUpdateSchool != null) {
            val newPaths = uris.mapNotNull { com.example.util.AttachmentHelper.saveUriToInternalStorage(context, it, "school_doc") }
            if (newPaths.isNotEmpty()) {
                onUpdateSchool(school.copy(attachedFiles = school.attachedFiles + newPaths))
            }
        }
    }

    val imgPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (school != null && onUpdateSchool != null) {
            val newPaths = uris.mapNotNull { com.example.util.AttachmentHelper.saveUriToInternalStorage(context, it, "school_img") }
            if (newPaths.isNotEmpty()) {
                onUpdateSchool(school.copy(attachedFiles = school.attachedFiles + newPaths))
            }
        }
    }

    if (viewingAttachment != null && school != null) {
        com.example.ui.components.AttachmentViewerDialog(
            filePath = viewingAttachment!!,
            onDismiss = { viewingAttachment = null },
            onDelete = {
                val target = viewingAttachment
                if (target != null && onUpdateSchool != null) {
                    onUpdateSchool(school.copy(attachedFiles = school.attachedFiles.filter { it != target }))
                }
                viewingAttachment = null
            }
        )
    }

    if (school == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val schoolTeachers = teachers.filter { it.schoolName == school.name }
    val schoolIncidents = incidents.filter { it.schoolName == school.name }
    val ongoingIncidents = schoolIncidents.filter { it.status == IncidentStatus.IN_PROGRESS }
    val schoolLogs = dailyLogs.filter { it.schoolName == school.name }
    val schoolTrips = trips.filter { it.schoolId == school.id || it.schoolName == school.name }

    Scaffold(
        topBar = {
            CompactTopBar(
                title = school.name,
                onBackClick = onBackClick,
                actions = {
                    if (school.phone.isNotBlank()) {
                        IconButton(
                            onClick = { WhatsAppHelper.makePhoneCall(context, school.phone) },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = "اتصال بالمدرسة", tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // أزرار الإجراءات السريعة (تسجيل رحلة / تسجيل واقعة / تفاصيل المدرسة)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showAddTripDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("btn_school_add_trip"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EduBlue)
                ) {
                    Icon(Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تسجيل رحلة", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                }
                Button(
                    onClick = { onAddIncidentClick(school.name) },
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("fab_school_add_incident"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EduGreen)
                ) {
                    Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تسجيل واقعة", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                }
                OutlinedButton(
                    onClick = { showSummary = !showSummary },
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("btn_school_toggle_details"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (showSummary) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("التفاصيل", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }

            // School Summary Card (قابلة للطي لتوفير مساحة للتبويبات)
            if (showSummary) Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = EduBlue.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = school.stage.displayNameAr,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EduBlue,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            if (school.code.isNotBlank()) {
                                Surface(
                                    color = EduGold.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "كود: ${school.code}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = EduGoldDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            if (school.serialNumber.isNotBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "مسلسل: ${school.serialNumber}",
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = school.address,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "مدير المدرسة:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = school.principalName.ifBlank { "غير مسجل" },
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (school.principalPhone.isNotBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(
                                        text = school.principalPhone,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EduBlue
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { WhatsAppHelper.makePhoneCall(context, school.principalPhone) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = EduBlue, modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            WhatsAppHelper.openWhatsApp(
                                                context,
                                                school.principalPhone,
                                                "السلام عليكم أ/ ${school.principalName}، معك أمن الإدارة التعليمية بسمالوط (مسؤول الأمن: مستر مصطفى فرغلي) بخصوص متابعة مدرسة ${school.name}."
                                            )
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = "واتساب", tint = Color(0xFF2E7D32), modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "مسؤول أمن المدرسة:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = school.securityOfficerName.ifBlank { "مستر مصطفى فرغلي" },
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            if (school.securityOfficerPhone.isNotBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    Text(
                                        text = school.securityOfficerPhone,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EduGreen
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { WhatsAppHelper.makePhoneCall(context, school.securityOfficerPhone) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = EduGreen, modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            WhatsAppHelper.openWhatsApp(
                                                context,
                                                school.securityOfficerPhone,
                                                "السلام عليكم أ/ ${school.securityOfficerName}، معك أمن الإدارة التعليمية بسمالوط (مستر مصطفى فرغلي) لمتابعة الأمن في ${school.name}."
                                            )
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = "واتساب", tint = Color(0xFF2E7D32), modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }

                    if (school.vicePrincipals.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "وكلاء المدرسة (${school.vicePrincipals.size}):",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        school.vicePrincipals.forEachIndexed { idx, vp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}. ${vp.name.ifBlank { "وكيل" }}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (vp.phone.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = vp.phone,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EduBlue
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { WhatsAppHelper.makePhoneCall(context, vp.phone) },
                                            modifier = Modifier.size(22.dp)
                                        ) {
                                            Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = EduBlue, modifier = Modifier.size(13.dp))
                                        }
                                        IconButton(
                                            onClick = {
                                                WhatsAppHelper.openWhatsApp(
                                                    context,
                                                    vp.phone,
                                                    "السلام عليكم أ/ ${vp.name}، معك أمن الإدارة التعليمية بسمالوط (مستر مصطفى فرغلي) بخصوص مدرسة ${school.name}."
                                                )
                                            },
                                            modifier = Modifier.size(22.dp)
                                        ) {
                                            Icon(Icons.Default.Chat, contentDescription = "واتساب", tint = Color(0xFF2E7D32), modifier = Modifier.size(13.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Equipment and Counts
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🏫 فصول: ${school.classroomsCount} | معلمين: ${school.teachersCount} | عمال: ${school.workersCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🏢 مباني: ${school.buildingsCount} | 🧯 طفايات: ${school.extinguishersCount} | 📹 كاميرات: ${school.camerasCount}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = EduBlueDark
                        )
                    }

                    // Notes
                    if (school.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = EduBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ملاحظات المدرسة: ${school.notes}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Attached Files (PDFs / Images)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المستندات والقرارات المرفقة (${school.attachedFiles.size}):",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = EduBlue
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = { docPicker.launch(arrayOf("application/pdf", "*/*")) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PDF / قرار", style = MaterialTheme.typography.labelSmall)
                            }
                            FilledTonalButton(
                                onClick = {
                                    imgPicker.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("صورة", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    if (school.attachedFiles.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        school.attachedFiles.forEach { filePath ->
                            val isPdf = com.example.util.AttachmentHelper.isPdf(filePath)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .clickable { viewingAttachment = filePath },
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                            contentDescription = null,
                                            tint = if (isPdf) Color(0xFFD32F2F) else EduBlue,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = com.example.util.AttachmentHelper.getDisplayName(filePath),
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Text(
                                            text = com.example.util.AttachmentHelper.getFileSizeFormatted(filePath),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        IconButton(
                                            onClick = { com.example.util.AttachmentHelper.shareToWhatsApp(context, filePath) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Chat, contentDescription = "مشاركة واتساب", tint = Color(0xFF2E7D32), modifier = Modifier.size(15.dp))
                                        }
                                        IconButton(
                                            onClick = { com.example.util.AttachmentHelper.printAttachment(context, filePath) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = "طباعة", tint = EduBlue, modifier = Modifier.size(15.dp))
                                        }
                                        IconButton(
                                            onClick = { viewingAttachment = filePath },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Visibility, contentDescription = "معاينة", tint = EduBlueDark, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Tabs: العاملون | الرحلات | الأحداث الجارية | سجل الأحداث | الحدث اليومي
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 8.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EduBlue
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("العاملون (${schoolTeachers.size})", style = MaterialTheme.typography.labelMedium, maxLines = 1, softWrap = false) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("الرحلات (${schoolTrips.size})", style = MaterialTheme.typography.labelMedium, maxLines = 1, softWrap = false) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            "الأحداث الجارية (${ongoingIncidents.size})",
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            softWrap = false,
                            color = if (ongoingIncidents.isNotEmpty()) SeverityHigh else LocalContentColor.current
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("سجل الأحداث (${schoolIncidents.size})", style = MaterialTheme.typography.labelMedium, maxLines = 1, softWrap = false) }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("الحدث اليومي (${schoolLogs.size})", style = MaterialTheme.typography.labelMedium, maxLines = 1, softWrap = false) }
                )
            }

            // Tab Content
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                when (selectedTab) {
                    0 -> {
                        // Staff / Teachers
                        if (schoolTeachers.isEmpty()) {
                            EmptyTabNotice("لا يوجد معلمون مسجلون في هذه المدرسة حتى الآن")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(schoolTeachers, key = { it.id }) { teacher ->
                                    TeacherItemCompact(
                                        teacher = teacher,
                                        onClick = { onTeacherClick(teacher.id) },
                                        onWhatsAppClick = {
                                            WhatsAppHelper.openWhatsApp(
                                                context,
                                                teacher.phone,
                                                "السلام عليكم أ/ ${teacher.name}، معك إدارة أمن الإدارة التعليمية بسمالوط (مسؤول الأمن: مستر مصطفى فرغلي) بخصوص مدرسة ${school.name}."
                                            )
                                        },
                                        onCallClick = {
                                            WhatsAppHelper.makePhoneCall(context, teacher.phone)
                                        }
                                    )
                                }
                            }
                        }
                    }
                    2 -> {
                        // Ongoing Incidents
                        if (ongoingIncidents.isEmpty()) {
                            EmptyTabNotice("لا توجد أحداث جارية حالياً بالمدرسة - الحالة مستقرة والحمد لله")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(ongoingIncidents, key = { it.id }) { incident ->
                                    RecentIncidentItem(
                                        incident = incident,
                                        onClick = { onIncidentClick(incident.id) }
                                    )
                                }
                            }
                        }
                    }
                    3 -> {
                        // All Incident History
                        if (schoolIncidents.isEmpty()) {
                            EmptyTabNotice("سجل أحداث هذه المدرسة نظيف تماماً")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(schoolIncidents, key = { it.id }) { incident ->
                                    RecentIncidentItem(
                                        incident = incident,
                                        onClick = { onIncidentClick(incident.id) }
                                    )
                                }
                            }
                        }
                    }
                    4 -> {
                        // Daily Logs
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "ملاحظات المرور اليومي والأمني",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                TextButton(onClick = { showAddLogDialog = true }) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة ملاحظة")
                                }
                            }

                            if (schoolLogs.isEmpty()) {
                                EmptyTabNotice("لا توجد ملاحظات يومية مسجلة لهذه المدرسة")
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(schoolLogs, key = { it.id }) { log ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                        ) {
                                            Column(modifier = Modifier.padding(14.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = log.dateString,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = EduBlue
                                                    )
                                                    Text(
                                                        text = log.supervisor,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(
                                                    text = log.note,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        // School Trips & Activities
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الرحلات والأنشطة المدرسية (${schoolTrips.size})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                FilledTonalButton(
                                    onClick = { showAddTripDialog = true },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تسجيل رحلة مدرسية", style = MaterialTheme.typography.labelSmall)
                                }
                            }

                            if (schoolTrips.isEmpty()) {
                                EmptyTabNotice("لا توجد رحلات مدرسية مسجلة لهذه المدرسة حتى الآن")
                            } else {
                                LazyColumn(
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(schoolTrips, key = { it.id }) { trip ->
                                        SchoolTripItemCard(
                                            trip = trip,
                                            onPrintItinerary = {
                                                com.example.util.TripReportHelper.shareTripItinerary(context, trip, adminConfig)
                                            },
                                            onDelete = { onDeleteTrip(trip) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Log Dialog
    if (showAddLogDialog) {
        AlertDialog(
            onDismissRequest = { showAddLogDialog = false },
            title = { Text("تسجيل ملاحظة مرور أمني يومي") },
            text = {
                OutlinedTextField(
                    value = logNoteText,
                    onValueChange = { logNoteText = it },
                    label = { Text("نص الملاحظة اليومية للمدرسة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (logNoteText.isNotBlank()) {
                            onAddDailyLog(
                                DailyLogEntry(
                                    schoolName = school.name,
                                    note = logNoteText.trim(),
                                    supervisor = "مستر مصطفى فرغلي"
                                )
                            )
                            logNoteText = ""
                            showAddLogDialog = false
                        }
                    }
                ) {
                    Text("حفظ الملاحظة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddLogDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add School Trip Dialog
    if (showAddTripDialog) {
        AddSchoolTripDialog(
            school = school,
            schoolTeachers = schoolTeachers,
            onDismiss = { showAddTripDialog = false },
            onConfirm = { newTrip ->
                onAddTrip(newTrip)
                showAddTripDialog = false
            }
        )
    }
}

@Composable
fun TeacherItemCompact(
    teacher: Teacher,
    onClick: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onCallClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(EduBlue.copy(alpha = 0.1f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = null, tint = EduBlue)
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = teacher.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${teacher.jobTitle} • ${teacher.subject}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // WhatsApp button
            IconButton(onClick = onWhatsAppClick) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = "مراسلة واتساب",
                    tint = EduGreen
                )
            }
            // Call button
            IconButton(onClick = onCallClick) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "اتصال",
                    tint = EduBlue
                )
            }
        }
    }
}

@Composable
fun EmptyTabNotice(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SchoolTripItemCard(
    trip: com.example.data.model.SchoolTripEntity,
    onPrintItinerary: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Destination & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsBus,
                        contentDescription = null,
                        tint = EduBlue,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = trip.destination,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    color = if (trip.approvalStatus.contains("معتمد")) EduGreen.copy(alpha = 0.15f) else EduGold.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = trip.approvalStatus,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (trip.approvalStatus.contains("معتمد")) EduGreenDark else EduGoldDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Date and Time & Students Count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "📅 ${trip.tripDate} • ⏰ ${trip.assemblyTime}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "👥 ${trip.studentsCount} طالب",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = EduBlue
                )
            }

            // Bus & Transport info
            if (trip.transportCompany.isNotBlank() || trip.busNumber.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "🚌 النقل: ${trip.transportCompany.ifBlank { "شركة سياحية" }} | الأتوبيس: ${trip.busNumber.ifBlank { "مُحدد ومفحوص" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Supervisors List
            if (trip.supervisors.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "مشرفو الرحلة (${trip.supervisors.size}):",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    trip.supervisors.take(3).forEach { supervisor ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "👤 $supervisor",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (trip.supervisors.size > 3) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "+${trip.supervisors.size - 3} آخرين",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Route & Security Instructions
            if (trip.routePlan.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "🗺️ خط السير: ${trip.routePlan}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = onPrintItinerary,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("طباعة بيان خط السير والتأمين", style = MaterialTheme.typography.labelSmall)
                }

                IconButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف الرحلة",
                        tint = SeverityHigh,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف سجل الرحلة") },
            text = { Text("هل أنت متأكد من حذف رحلة (${trip.destination})؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SeverityHigh)
                ) {
                    Text("تأكيد الحذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSchoolTripDialog(
    school: School,
    schoolTeachers: List<Teacher>,
    onDismiss: () -> Unit,
    onConfirm: (com.example.data.model.SchoolTripEntity) -> Unit
) {
    val context = LocalContext.current
    val calendar = java.util.Calendar.getInstance()
    val todayFormatted = java.text.SimpleDateFormat("dd / MM / yyyy", java.util.Locale("ar")).format(calendar.time)

    var destination by remember { mutableStateOf("") }
    var tripDate by remember { mutableStateOf(todayFormatted) }
    var assemblyTime by remember { mutableStateOf("07:30 صباحاً") }
    var studentsCountText by remember { mutableStateOf("45") }
    var transportCompany by remember { mutableStateOf("") }
    var busNumber by remember { mutableStateOf("") }
    var routePlan by remember { mutableStateOf("") }
    var securityInstructions by remember {
        mutableStateOf("الالتزام التام بعدد الطلاب المصرح به، توافر حقيبة إسعافات أولية، فحص رخصة السائق وصلاحية الحافلة، والالتزام بالعودة قبل غروب الشمس.")
    }
    var selectedSupervisors by remember { mutableStateOf<List<String>>(emptyList()) }
    var supervisorSearch by remember { mutableStateOf("") }
    var customSupervisorText by remember { mutableStateOf("") }
    var approvalStatus by remember { mutableStateOf("معتمدة من أمن الإدارة") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DirectionsBus, contentDescription = null, tint = EduBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تسجيل رحلة مدرسية جديدة", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        label = { Text("وجهة ومكان الرحلة * (مثال: الأهرامات / حديقة الحيوان)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = tripDate,
                            onValueChange = { tripDate = it },
                            label = { Text("تاريخ الرحلة *") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = assemblyTime,
                            onValueChange = { assemblyTime = it },
                            label = { Text("ساعة التجمع") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = studentsCountText,
                            onValueChange = { studentsCountText = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد الطلاب") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = busNumber,
                            onValueChange = { busNumber = it },
                            label = { Text("رقم الحافلة") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = transportCompany,
                        onValueChange = { transportCompany = it },
                        label = { Text("شركة النقل المتعاقد معها") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = routePlan,
                        onValueChange = { routePlan = it },
                        label = { Text("خط السير ومحطات التوقف") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Text(
                        text = "مشرفو الرحلة (اختر من معلمي المدرسة):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (schoolTeachers.isNotEmpty()) {
                    item {
                        OutlinedTextField(
                            value = supervisorSearch,
                            onValueChange = { supervisorSearch = it },
                            label = { Text("بحث في معلمي المدرسة") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    item {
                        val filteredTeachers = schoolTeachers.filter {
                            supervisorSearch.isBlank() || it.name.contains(supervisorSearch.trim(), ignoreCase = true)
                        }
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "تم اختيار ${selectedSupervisors.size} مشرف • اسحب القائمة لأسفل لعرض باقي المعلمين (${filteredTeachers.size})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                // قائمة مشرفين بارتفاع ثابت وتمرير مستقل
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp)
                                ) {
                                    items(filteredTeachers, key = { it.id }) { teacher ->
                                        val isChecked = selectedSupervisors.contains(teacher.name)
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedSupervisors = if (isChecked) {
                                                        selectedSupervisors - teacher.name
                                                    } else {
                                                        selectedSupervisors + teacher.name
                                                    }
                                                }
                                                .padding(vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = isChecked,
                                                onCheckedChange = { checked ->
                                                    selectedSupervisors = if (checked) {
                                                        selectedSupervisors + teacher.name
                                                    } else {
                                                        selectedSupervisors - teacher.name
                                                    }
                                                }
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${teacher.name} (${teacher.jobTitle})",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customSupervisorText,
                            onValueChange = { customSupervisorText = it },
                            label = { Text("إضافة مشرف آخر بالاسم") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FilledTonalButton(
                            onClick = {
                                if (customSupervisorText.isNotBlank()) {
                                    selectedSupervisors = selectedSupervisors + customSupervisorText.trim()
                                    customSupervisorText = ""
                                }
                            }
                        ) {
                            Text("إضافة")
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = securityInstructions,
                        onValueChange = { securityInstructions = it },
                        label = { Text("اشتراطات وتعليمات التأمين") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }

                item {
                    OutlinedTextField(
                        value = approvalStatus,
                        onValueChange = { approvalStatus = it },
                        label = { Text("حالة الاعتماد الأمني") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (destination.isNotBlank()) {
                        val newTrip = com.example.data.model.SchoolTripEntity(
                            schoolId = school.id,
                            schoolName = school.name,
                            destination = destination.trim(),
                            tripDate = tripDate.trim(),
                            assemblyTime = assemblyTime.trim(),
                            supervisors = selectedSupervisors,
                            studentsCount = studentsCountText.toIntOrNull() ?: 0,
                            transportCompany = transportCompany.trim(),
                            busNumber = busNumber.trim(),
                            routePlan = routePlan.trim(),
                            securityInstructions = securityInstructions.trim(),
                            approvalStatus = approvalStatus.trim()
                        )
                        onConfirm(newTrip)
                    }
                },
                enabled = destination.isNotBlank()
            ) {
                Text("حفظ واعتماد الرحلة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
