package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduGreen
import com.example.util.AttachmentHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * عارض داخلي تفاعلي للمستندات والملفات المرفقة (PDF والصور)
 */
@Composable
fun AttachmentViewerDialog(
    filePath: String,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val isPdf = AttachmentHelper.isPdf(filePath)
    val isImg = AttachmentHelper.isImage(filePath)
    val displayName = AttachmentHelper.getDisplayName(filePath)
    val fileSize = AttachmentHelper.getFileSizeFormatted(filePath)
    val fileDate = AttachmentHelper.getFileDateFormatted(filePath)
    var showDeleteConfirm by remember { mutableStateOf(false) }

    // Render PDF first page asynchronously
    var pdfBitmap by remember(filePath) { mutableStateOf<Bitmap?>(null) }
    var isLoadingPdf by remember(filePath) { mutableStateOf(isPdf) }

    LaunchedEffect(filePath) {
        if (isPdf) {
            isLoadingPdf = true
            pdfBitmap = withContext(Dispatchers.IO) {
                AttachmentHelper.renderPdfFirstPage(filePath)
            }
            isLoadingPdf = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.92f)
                .testTag("dialog_attachment_viewer"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Surface(
                    color = if (isPdf) Color(0xFFC62828) else EduBlue,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = displayName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$fileSize • $fileDate",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                        }
                    }
                }

                // Main Viewer Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF1E1E1E))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    when {
                        isImg -> {
                            // Image Viewer with Coil
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(File(filePath))
                                    .crossfade(true)
                                    .build(),
                                contentDescription = displayName,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Fit
                            )
                        }
                        isPdf -> {
                            // PDF Viewer / Preview
                            if (isLoadingPdf) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color.White)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("جاري قراءة ومعاينة مستند PDF...", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                }
                            } else if (pdfBitmap != null) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Surface(
                                        color = Color.White,
                                        shape = RoundedCornerShape(8.dp),
                                        shadowElevation = 8.dp,
                                        modifier = Modifier.padding(12.dp)
                                    ) {
                                        Image(
                                            bitmap = pdfBitmap!!.asImageBitmap(),
                                            contentDescription = "معاينة الصفحة الأولى لمستند PDF",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp)),
                                            contentScale = ContentScale.FillWidth
                                        )
                                    }
                                    Text(
                                        text = "الصفحة الأولى من المستند",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.7f),
                                        modifier = Modifier.padding(bottom = 12.dp)
                                    )
                                }
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PictureAsPdf,
                                        contentDescription = null,
                                        tint = Color(0xFFEF5350),
                                        modifier = Modifier.size(72.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = displayName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "مستند رسمي مخصص لقسم الأمن والحماية",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.75f)
                                    )
                                }
                            }
                        }
                        else -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(displayName, color = Color.White, style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }

                // Action Bar Footer
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Open External / PDF Reader
                        Button(
                            onClick = { AttachmentHelper.openAttachment(context, filePath) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EduBlue)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isPdf) "فتح PDF" else "فتح", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }

                        // WhatsApp Direct Share
                        FilledTonalButton(
                            onClick = { AttachmentHelper.shareToWhatsApp(context, filePath) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF2E7D32).copy(alpha = 0.15f),
                                contentColor = Color(0xFF1B5E20)
                            )
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("واتساب", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }

                        // Direct Print
                        OutlinedButton(
                            onClick = { AttachmentHelper.printAttachment(context, filePath) },
                            modifier = Modifier.weight(0.9f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(17.dp), tint = EduBlue)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("طباعة", color = EduBlue, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }

                        // Delete
                        if (onDelete != null) {
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f), CircleShape)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف المرفق", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm && onDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("تأكيد حذف المرفق") },
            text = { Text("هل أنت متأكد من حذف هذا الملف المرفق («$displayName»)؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        AttachmentHelper.deleteAttachmentFile(filePath)
                        onDelete()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
