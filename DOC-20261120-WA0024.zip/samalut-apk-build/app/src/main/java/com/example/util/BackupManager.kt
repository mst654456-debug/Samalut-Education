package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.local.AppDatabase
import com.example.data.model.DailyLogEntry
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.model.VicePrincipal
import com.example.data.preferences.AdminConfig
import com.example.data.preferences.AdminPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class BackupResult(
    val success: Boolean,
    val backupFile: File? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val schoolsCount: Int = 0,
    val teachersCount: Int = 0,
    val incidentsCount: Int = 0,
    val logsCount: Int = 0,
    val attachmentsCount: Int = 0,
    val fileSizeFormatted: String = "",
    val message: String = ""
) {
    val zipPath: String get() = backupFile?.absolutePath ?: ""
}

data class RestoreResult(
    val success: Boolean,
    val schoolsRestored: Int = 0,
    val teachersRestored: Int = 0,
    val incidentsRestored: Int = 0,
    val logsRestored: Int = 0,
    val attachmentsRestored: Int = 0,
    val backupDateString: String = "",
    val message: String = ""
) {
    val schoolsCount: Int get() = schoolsRestored
    val teachersCount: Int get() = teachersRestored
    val incidentsCount: Int get() = incidentsRestored
}

object BackupManager {

    private const val BACKUP_DIR_NAME = "backups"
    private const val ATTACHMENTS_DIR_NAME = "attachments"

    fun shareBackupFile(context: Context, zipFile: File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(intent, "مشاركة / حفظ النسخة الاحتياطية"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * تصدير ورفع النسخة الاحتياطية مباشرة إلى Google Drive
     * يقوم بتجهيز الـ Intent الموجه لتطبيق Google Drive لحفظ النسخة الاحتياطية المضغوطة ZIP
     */
    fun exportToGoogleDrive(context: Context, zipFile: File) {
        try {
            if (!zipFile.exists()) {
                android.widget.Toast.makeText(context, "ملف النسخة الاحتياطية غير موجود", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )
            val driveIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/zip"
                `package` = "com.google.android.apps.docs"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                putExtra(android.content.Intent.EXTRA_TITLE, zipFile.name)
                putExtra(android.content.Intent.EXTRA_SUBJECT, "نسخة احتياطية - أمن إدارة سمالوط التعليمية")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(driveIntent)
        } catch (e: Exception) {
            // Fallback to chooser targeting cloud drives
            val chooserIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "application/zip"
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    zipFile
                )
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                putExtra(android.content.Intent.EXTRA_SUBJECT, "نسخة احتياطية - أمن سمالوط التعليمية")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(chooserIntent, "حفظ ورفع النسخة الاحتياطية إلى Google Drive"))
        }
    }

    /**
     * المجلد المخصص لحفظ النسخ الاحتياطية داخل التطبيق
     */
    fun getBackupDirectory(context: Context): File {
        val dir = File(context.filesDir, BACKUP_DIR_NAME)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * استرجاع قائمة النسخ الاحتياطية المحفوظة محلياً
     */
    fun getLocalBackupFiles(context: Context): List<File> {
        val dir = getBackupDirectory(context)
        return dir.listFiles { file -> file.extension.equals("zip", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?.toList() ?: emptyList()
    }

    /**
     * إنشاء نسخة احتياطية كاملة (قاعدة بيانات Room + المرفقات + الإعدادات) وتصديرها بصيغة ZIP
     */
    suspend fun createFullBackup(
        context: Context,
        database: AppDatabase,
        adminPreferences: AdminPreferences? = null
    ): BackupResult = withContext(Dispatchers.IO) {
        try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val dateDisplay = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())
            val backupDir = getBackupDirectory(context)
            val zipFileName = "backup_samalut_security_${timeStamp}.zip"
            val zipFile = File(backupDir, zipFileName)

            // جمع بيانات قاعدة البيانات
            val schools = database.schoolDao().getAllSchools().first()
            val teachers = database.teacherDao().getAllTeachers().first()
            val incidents = database.securityIncidentDao().getAllIncidents().first()
            val logs = database.dailyLogDao().getAllLogs().first()
            val leaves = database.teacherLeaveDao().getAllLeaves().first()
            val penalties = database.teacherPenaltyDao().getAllPenalties().first()
            val trips = database.schoolTripDao().getAllTrips().first()
            val adminConfig = adminPreferences?.adminConfig?.first() ?: AdminConfig()

            // 1. بناء ملف JSON الشامل
            val rootJson = JSONObject().apply {
                put("version", 1)
                put("app_name", "إدارة أمن الإدارة التعليمية بسمالوط")
                put("supervisor", adminConfig.securityOfficerName)
                put("director_general", adminConfig.directorGeneralName)
                put("administration", adminConfig.administrationName)
                put("directorate", adminConfig.directorateName)
                put("created_at", System.currentTimeMillis())
                put("created_at_display", dateDisplay)

                // Admin Config
                put("admin_config", JSONObject().apply {
                    put("directorate", adminConfig.directorateName)
                    put("administration", adminConfig.administrationName)
                    put("director_general", adminConfig.directorGeneralName)
                    put("security_officer", adminConfig.securityOfficerName)
                })

                // Schools Array
                val schoolsArr = JSONArray()
                schools.forEach { s ->
                    val obj = JSONObject().apply {
                        put("id", s.id)
                        put("governorate", s.governorate)
                        put("administration", s.administration)
                        put("name", s.name)
                        put("code", s.code)
                        put("serialNumber", s.serialNumber)
                        put("stage", s.stage.name)
                        put("principalName", s.principalName)
                        put("principalPhone", s.principalPhone)
                        put("securityOfficerName", s.securityOfficerName)
                        put("securityOfficerPhone", s.securityOfficerPhone)
                        put("classroomsCount", s.classroomsCount)
                        put("teachersCount", s.teachersCount)
                        put("workersCount", s.workersCount)
                        put("buildingsCount", s.buildingsCount)
                        put("extinguishersCount", s.extinguishersCount)
                        put("camerasCount", s.camerasCount)
                        put("address", s.address)
                        put("phone", s.phone)
                        put("notes", s.notes)

                        val vpArr = JSONArray()
                        s.vicePrincipals.forEach { vp ->
                            vpArr.put(JSONObject().apply {
                                put("name", vp.name)
                                put("phone", vp.phone)
                            })
                        }
                        put("vicePrincipals", vpArr)

                        val filesArr = JSONArray()
                        s.attachedFiles.forEach { f -> filesArr.put(File(f).name) }
                        put("attachedFiles", filesArr)
                    }
                    schoolsArr.put(obj)
                }
                put("schools", schoolsArr)

                // Teachers Array
                val teachersArr = JSONArray()
                teachers.forEach { t ->
                    val obj = JSONObject().apply {
                        put("id", t.id)
                        put("name", t.name)
                        put("teacherCode", t.teacherCode)
                        put("nationalId", t.nationalId)
                        put("schoolName", t.schoolName)
                        put("stage", t.stage.name)
                        put("jobTitle", t.jobTitle)
                        put("assignedDuty", t.assignedDuty)
                        put("phone", t.phone)
                        put("address", t.address)
                        put("subject", t.subject)
                        put("hireDate", t.hireDate)
                        put("notes", t.notes)

                        val filesArr = JSONArray()
                        t.attachedFiles.forEach { f -> filesArr.put(File(f).name) }
                        put("attachedFiles", filesArr)
                    }
                    teachersArr.put(obj)
                }
                put("teachers", teachersArr)

                // Incidents Array
                val incidentsArr = JSONArray()
                incidents.forEach { inc ->
                    val obj = JSONObject().apply {
                        put("id", inc.id)
                        put("title", inc.title)
                        put("description", inc.description)
                        put("schoolName", inc.schoolName)
                        put("partiesInvolved", inc.partiesInvolved)
                        put("actionTaken", inc.actionTaken)
                        put("status", inc.status.name)
                        put("dateString", inc.dateString)
                        put("timeString", inc.timeString)
                        put("timestamp", inc.timestamp)
                        put("supervisor", inc.supervisor)

                        val imgArr = JSONArray()
                        inc.imageUris.forEach { u -> imgArr.put(File(u).name) }
                        put("imageUris", imgArr)
                    }
                    incidentsArr.put(obj)
                }
                put("incidents", incidentsArr)

                // Daily Logs Array
                val logsArr = JSONArray()
                logs.forEach { l ->
                    val obj = JSONObject().apply {
                        put("id", l.id)
                        put("dateString", l.dateString)
                        put("schoolName", l.schoolName)
                        put("teacherName", l.teacherName)
                        put("note", l.note)
                        put("supervisor", l.supervisor)
                        put("timestamp", l.timestamp)
                    }
                    logsArr.put(obj)
                }
                put("logs", logsArr)

                // Teacher Leaves Array
                val leavesArr = JSONArray()
                leaves.forEach { lv ->
                    val obj = JSONObject().apply {
                        put("id", lv.id)
                        put("teacherId", lv.teacherId)
                        put("teacherName", lv.teacherName)
                        put("schoolName", lv.schoolName)
                        put("leaveType", lv.leaveType)
                        put("startDate", lv.startDate)
                        put("endDate", lv.endDate)
                        put("daysCount", lv.daysCount)
                        put("destination", lv.destination)
                        put("notes", lv.notes)
                        put("timestamp", lv.timestamp)
                    }
                    leavesArr.put(obj)
                }
                put("leaves", leavesArr)

                // Teacher Penalties Array
                val penaltiesArr = JSONArray()
                penalties.forEach { p ->
                    val obj = JSONObject().apply {
                        put("id", p.id)
                        put("teacherId", p.teacherId)
                        put("teacherName", p.teacherName)
                        put("schoolName", p.schoolName)
                        put("penaltyType", p.penaltyType)
                        put("daysDeducted", p.daysDeducted)
                        put("reason", p.reason)
                        put("issuingAuthority", p.issuingAuthority)
                        put("dateString", p.dateString)
                        put("decisionNumber", p.decisionNumber)
                        put("notes", p.notes)
                        put("timestamp", p.timestamp)
                    }
                    penaltiesArr.put(obj)
                }
                put("penalties", penaltiesArr)

                // School Trips Array
                val tripsArr = JSONArray()
                trips.forEach { tr ->
                    val obj = JSONObject().apply {
                        put("id", tr.id)
                        put("schoolId", tr.schoolId)
                        put("schoolName", tr.schoolName)
                        put("destination", tr.destination)
                        put("tripDate", tr.tripDate)
                        put("assemblyTime", tr.assemblyTime)
                        put("studentsCount", tr.studentsCount)
                        put("transportCompany", tr.transportCompany)
                        put("busNumber", tr.busNumber)
                        put("routePlan", tr.routePlan)
                        put("securityInstructions", tr.securityInstructions)
                        put("approvalStatus", tr.approvalStatus)
                        put("timestamp", tr.timestamp)
                        val supArr = JSONArray()
                        tr.supervisors.forEach { s -> supArr.put(s) }
                        put("supervisors", supArr)
                    }
                    tripsArr.put(obj)
                }
                put("trips", tripsArr)
            }

            // 2. كتابة ملف ZIP
            var attachmentsCount = 0
            val attachmentsDir = File(context.filesDir, ATTACHMENTS_DIR_NAME)

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                // A) كتابة بيانات JSON داخل ملف data.json
                val dataEntry = ZipEntry("backup_data.json")
                zos.putNextEntry(dataEntry)
                zos.write(rootJson.toString(2).toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                // B) كتابة ملف الوصف metadata.json
                val metaJson = JSONObject().apply {
                    put("appName", "إدارة أمن سمالوط التعليمية")
                    put("date", dateDisplay)
                    put("timestamp", System.currentTimeMillis())
                    put("schools", schools.size)
                    put("teachers", teachers.size)
                    put("incidents", incidents.size)
                    put("logs", logs.size)
                }
                val metaEntry = ZipEntry("backup_metadata.json")
                zos.putNextEntry(metaEntry)
                zos.write(metaJson.toString(2).toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                // C) إضافة المرفقات إن وجدت
                if (attachmentsDir.exists() && attachmentsDir.isDirectory) {
                    val files = attachmentsDir.listFiles() ?: emptyArray()
                    val buffer = ByteArray(8192)
                    for (file in files) {
                        if (file.isFile) {
                            try {
                                val entry = ZipEntry("attachments/${file.name}")
                                zos.putNextEntry(entry)
                                BufferedInputStream(FileInputStream(file)).use { bis ->
                                    var read: Int
                                    while (bis.read(buffer).also { read = it } != -1) {
                                        zos.write(buffer, 0, read)
                                    }
                                }
                                zos.closeEntry()
                                attachmentsCount++
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                }
            }

            val sizeKb = (zipFile.length() / 1024).coerceAtLeast(1)
            val sizeFormatted = if (sizeKb >= 1024) String.format(Locale.US, "%.1f MB", sizeKb / 1024.0) else "$sizeKb KB"

            // حفظ وقت النسخ الاحتياطي في SharedPreferences
            context.getSharedPreferences("samalut_backup_prefs", Context.MODE_PRIVATE).edit()
                .putLong("last_backup_timestamp", System.currentTimeMillis())
                .putString("last_backup_date", dateDisplay)
                .putString("last_backup_file", zipFile.absolutePath)
                .apply()

            BackupResult(
                success = true,
                backupFile = zipFile,
                timestamp = System.currentTimeMillis(),
                schoolsCount = schools.size,
                teachersCount = teachers.size,
                incidentsCount = incidents.size,
                logsCount = logs.size,
                attachmentsCount = attachmentsCount,
                fileSizeFormatted = sizeFormatted,
                message = "تم إنشاء النسخة الاحتياطية بنجاح (${zipFile.name}) بحجم $sizeFormatted"
            )
        } catch (e: Exception) {
            e.printStackTrace()
            BackupResult(
                success = false,
                message = "فشل إنشاء النسخة الاحتياطية: ${e.localizedMessage}"
            )
        }
    }

    /**
     * استرجاع البيانات كاملة من ملف النسخة الاحتياطية المضغوط (ZIP)
     */
    suspend fun restoreFromBackup(
        context: Context,
        zipUriOrFile: Any,
        database: AppDatabase,
        adminPreferences: AdminPreferences? = null
    ): RestoreResult = withContext(Dispatchers.IO) {
        try {
            var jsonContent: String? = null
            var attachmentsRestored = 0
            val attachmentsDir = File(context.filesDir, ATTACHMENTS_DIR_NAME).apply {
                if (!exists()) mkdirs()
            }

            val inputStream = when (zipUriOrFile) {
                is Uri -> context.contentResolver.openInputStream(zipUriOrFile)
                is File -> FileInputStream(zipUriOrFile)
                is String -> {
                    val f = File(zipUriOrFile)
                    if (f.exists()) FileInputStream(f) else context.contentResolver.openInputStream(Uri.parse(zipUriOrFile))
                }
                else -> null
            } ?: return@withContext RestoreResult(success = false, message = "تعذر فتح ملف النسخة الاحتياطية")

            val buffer = ByteArray(8192)
            ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name == "backup_data.json") {
                        val bytes = zis.readBytes()
                        jsonContent = String(bytes, Charsets.UTF_8)
                    } else if (name.startsWith("attachments/") && !entry.isDirectory) {
                        val fileName = name.substringAfterLast("/")
                        if (fileName.isNotBlank()) {
                            val destFile = File(attachmentsDir, fileName)
                            BufferedOutputStream(FileOutputStream(destFile)).use { bos ->
                                var count: Int
                                while (zis.read(buffer).also { count = it } != -1) {
                                    bos.write(buffer, 0, count)
                                }
                            }
                            attachmentsRestored++
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (jsonContent.isNullOrBlank()) {
                return@withContext RestoreResult(
                    success = false,
                    message = "الملف المضغوط لا يحتوي على بيانات أمن سمالوط الصالحة (backup_data.json غير موجود)"
                )
            }

            val rootJson = JSONObject(jsonContent)
            val dateDisplay = rootJson.optString("created_at_display", "")

            // 1. استرجاع الإعدادات الإدارية إن وجدت
            if (rootJson.has("admin_config") && adminPreferences != null) {
                val cfg = rootJson.getJSONObject("admin_config")
                adminPreferences.saveConfig(
                    directorate = cfg.optString("directorate", "مديرية التربية والتعليم بالمنيا"),
                    administration = cfg.optString("administration", "إدارة سمالوط التعليمية"),
                    directorGeneral = cfg.optString("director_general", "د/ علي عبد السلام"),
                    securityOfficer = cfg.optString("security_officer", "مستر مصطفى فرغلي"),
                    isCompleted = true
                )
            }

            // 2. استرجاع المدارس
            val schoolsDao = database.schoolDao()
            var schoolsRestored = 0
            if (rootJson.has("schools")) {
                val schoolsArr = rootJson.getJSONArray("schools")
                for (i in 0 until schoolsArr.length()) {
                    val obj = schoolsArr.getJSONObject(i)
                    val vpList = mutableListOf<VicePrincipal>()
                    if (obj.has("vicePrincipals")) {
                        val vps = obj.getJSONArray("vicePrincipals")
                        for (v in 0 until vps.length()) {
                            val vpObj = vps.getJSONObject(v)
                            vpList.add(
                                VicePrincipal(
                                    name = vpObj.optString("name", ""),
                                    phone = vpObj.optString("phone", "")
                                )
                            )
                        }
                    }

                    val filesList = mutableListOf<String>()
                    if (obj.has("attachedFiles")) {
                        val fArr = obj.getJSONArray("attachedFiles")
                        for (f in 0 until fArr.length()) {
                            val fName = fArr.getString(f)
                            val resolvedFile = File(attachmentsDir, fName)
                            filesList.add(resolvedFile.absolutePath)
                        }
                    }

                    val stageStr = obj.optString("stage", "PRIMARY")
                    val stage = try { SchoolStage.valueOf(stageStr) } catch (e: Exception) { SchoolStage.PRIMARY }

                    val school = School(
                        governorate = obj.optString("governorate", "المنيا"),
                        administration = obj.optString("administration", "سمالوط التعليمية"),
                        name = obj.optString("name", ""),
                        code = obj.optString("code", ""),
                        serialNumber = obj.optString("serialNumber", ""),
                        stage = stage,
                        principalName = obj.optString("principalName", ""),
                        principalPhone = obj.optString("principalPhone", ""),
                        vicePrincipals = vpList,
                        securityOfficerName = obj.optString("securityOfficerName", ""),
                        securityOfficerPhone = obj.optString("securityOfficerPhone", ""),
                        classroomsCount = obj.optInt("classroomsCount", 0),
                        teachersCount = obj.optInt("teachersCount", 0),
                        workersCount = obj.optInt("workersCount", 0),
                        buildingsCount = obj.optInt("buildingsCount", 0),
                        extinguishersCount = obj.optInt("extinguishersCount", 0),
                        camerasCount = obj.optInt("camerasCount", 0),
                        address = obj.optString("address", ""),
                        phone = obj.optString("phone", ""),
                        notes = obj.optString("notes", ""),
                        attachedFiles = filesList
                    )

                    val existing = if (school.code.isNotBlank()) {
                        schoolsDao.getSchoolByCode(school.code) ?: schoolsDao.getSchoolByName(school.name)
                    } else {
                        schoolsDao.getSchoolByName(school.name)
                    }

                    if (existing != null) {
                        schoolsDao.updateSchool(school.copy(id = existing.id))
                    } else {
                        schoolsDao.insertSchool(school)
                    }
                    schoolsRestored++
                }
            }

            // 3. استرجاع المعلمين
            val teacherDao = database.teacherDao()
            var teachersRestored = 0
            if (rootJson.has("teachers")) {
                val teachersArr = rootJson.getJSONArray("teachers")
                for (i in 0 until teachersArr.length()) {
                    val obj = teachersArr.getJSONObject(i)
                    val stageStr = obj.optString("stage", "PRIMARY")
                    val stage = try { SchoolStage.valueOf(stageStr) } catch (e: Exception) { SchoolStage.PRIMARY }

                    val filesList = mutableListOf<String>()
                    if (obj.has("attachedFiles")) {
                        val fArr = obj.getJSONArray("attachedFiles")
                        for (f in 0 until fArr.length()) {
                            val fName = fArr.getString(f)
                            val resolvedFile = File(attachmentsDir, fName)
                            filesList.add(resolvedFile.absolutePath)
                        }
                    }

                    val teacher = Teacher(
                        name = obj.optString("name", ""),
                        teacherCode = obj.optString("teacherCode", ""),
                        nationalId = obj.optString("nationalId", ""),
                        schoolName = obj.optString("schoolName", ""),
                        stage = stage,
                        jobTitle = obj.optString("jobTitle", "معلم"),
                        assignedDuty = obj.optString("assignedDuty", ""),
                        phone = obj.optString("phone", ""),
                        address = obj.optString("address", ""),
                        subject = obj.optString("subject", ""),
                        hireDate = obj.optString("hireDate", ""),
                        notes = obj.optString("notes", ""),
                        attachedFiles = filesList
                    )

                    val existing = if (teacher.teacherCode.isNotBlank()) {
                        teacherDao.getTeacherByCode(teacher.teacherCode)
                    } else if (teacher.nationalId.isNotBlank()) {
                        teacherDao.getTeacherByNationalId(teacher.nationalId)
                    } else null

                    if (existing != null) {
                        teacherDao.updateTeacher(teacher.copy(id = existing.id))
                    } else {
                        teacherDao.insertTeacher(teacher)
                    }
                    teachersRestored++
                }
            }

            // 4. استرجاع الوقائع والأحداث
            val incidentDao = database.securityIncidentDao()
            var incidentsRestored = 0
            if (rootJson.has("incidents")) {
                val incidentsArr = rootJson.getJSONArray("incidents")
                for (i in 0 until incidentsArr.length()) {
                    val obj = incidentsArr.getJSONObject(i)
                    val statusStr = obj.optString("status", "IN_PROGRESS")
                    val status = try { IncidentStatus.valueOf(statusStr) } catch (e: Exception) { IncidentStatus.IN_PROGRESS }

                    val imgList = mutableListOf<String>()
                    if (obj.has("imageUris")) {
                        val imgArr = obj.getJSONArray("imageUris")
                        for (m in 0 until imgArr.length()) {
                            val fName = imgArr.getString(m)
                            val resolvedFile = File(attachmentsDir, fName)
                            imgList.add(resolvedFile.absolutePath)
                        }
                    }

                    val incident = SecurityIncident(
                        title = obj.optString("title", ""),
                        description = obj.optString("description", ""),
                        schoolName = obj.optString("schoolName", ""),
                        partiesInvolved = obj.optString("partiesInvolved", ""),
                        actionTaken = obj.optString("actionTaken", ""),
                        status = status,
                        dateString = obj.optString("dateString", ""),
                        timeString = obj.optString("timeString", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        supervisor = obj.optString("supervisor", "مستر مصطفى فرغلي"),
                        imageUris = imgList
                    )
                    incidentDao.insertIncident(incident)
                    incidentsRestored++
                }
            }

            // 5. استرجاع سجلات المرور اليومي
            val logDao = database.dailyLogDao()
            var logsRestored = 0
            if (rootJson.has("logs")) {
                val logsArr = rootJson.getJSONArray("logs")
                for (i in 0 until logsArr.length()) {
                    val obj = logsArr.getJSONObject(i)
                    val log = DailyLogEntry(
                        dateString = obj.optString("dateString", ""),
                        schoolName = obj.optString("schoolName", ""),
                        teacherName = obj.optString("teacherName", ""),
                        note = obj.optString("note", ""),
                        supervisor = obj.optString("supervisor", "مستر مصطفى فرغلي"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                    logDao.insertLog(log)
                    logsRestored++
                }
            }

            // 6. استرجاع إجازات المعلمين
            val leaveDao = database.teacherLeaveDao()
            var leavesRestored = 0
            if (rootJson.has("leaves")) {
                val leavesArr = rootJson.getJSONArray("leaves")
                for (i in 0 until leavesArr.length()) {
                    val obj = leavesArr.getJSONObject(i)
                    val leave = com.example.data.model.TeacherLeaveEntity(
                        teacherId = obj.optLong("teacherId", 0L),
                        teacherName = obj.optString("teacherName", ""),
                        schoolName = obj.optString("schoolName", ""),
                        leaveType = obj.optString("leaveType", "اعتيادي"),
                        startDate = obj.optString("startDate", ""),
                        endDate = obj.optString("endDate", ""),
                        daysCount = obj.optInt("daysCount", 1),
                        destination = obj.optString("destination", "داخل القطر"),
                        notes = obj.optString("notes", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                    leaveDao.insertLeave(leave)
                    leavesRestored++
                }
            }

            // 7. استرجاع الجزاءات
            val penaltyDao = database.teacherPenaltyDao()
            var penaltiesRestored = 0
            if (rootJson.has("penalties")) {
                val penaltiesArr = rootJson.getJSONArray("penalties")
                for (i in 0 until penaltiesArr.length()) {
                    val obj = penaltiesArr.getJSONObject(i)
                    val penalty = com.example.data.model.TeacherPenaltyEntity(
                        teacherId = obj.optLong("teacherId", 0L),
                        teacherName = obj.optString("teacherName", ""),
                        schoolName = obj.optString("schoolName", ""),
                        penaltyType = obj.optString("penaltyType", "إنذار"),
                        daysDeducted = obj.optInt("daysDeducted", 0),
                        reason = obj.optString("reason", ""),
                        issuingAuthority = obj.optString("issuingAuthority", "الشؤون القانونية بالإدارة"),
                        dateString = obj.optString("dateString", ""),
                        decisionNumber = obj.optString("decisionNumber", ""),
                        notes = obj.optString("notes", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                    penaltyDao.insertPenalty(penalty)
                    penaltiesRestored++
                }
            }

            // 8. استرجاع الرحلات المدرسية
            val tripDao = database.schoolTripDao()
            var tripsRestored = 0
            if (rootJson.has("trips")) {
                val tripsArr = rootJson.getJSONArray("trips")
                for (i in 0 until tripsArr.length()) {
                    val obj = tripsArr.getJSONObject(i)
                    val supList = mutableListOf<String>()
                    if (obj.has("supervisors")) {
                        val sArr = obj.getJSONArray("supervisors")
                        for (s in 0 until sArr.length()) {
                            supList.add(sArr.getString(s))
                        }
                    }
                    val trip = com.example.data.model.SchoolTripEntity(
                        schoolId = obj.optLong("schoolId", 0L),
                        schoolName = obj.optString("schoolName", ""),
                        destination = obj.optString("destination", ""),
                        tripDate = obj.optString("tripDate", ""),
                        assemblyTime = obj.optString("assemblyTime", "07:00 ص"),
                        supervisors = supList,
                        studentsCount = obj.optInt("studentsCount", 0),
                        transportCompany = obj.optString("transportCompany", ""),
                        busNumber = obj.optString("busNumber", ""),
                        routePlan = obj.optString("routePlan", ""),
                        securityInstructions = obj.optString("securityInstructions", ""),
                        approvalStatus = obj.optString("approvalStatus", "معتمدة أمنياً"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                    tripDao.insertTrip(trip)
                    tripsRestored++
                }
            }

            RestoreResult(
                success = true,
                schoolsRestored = schoolsRestored,
                teachersRestored = teachersRestored,
                incidentsRestored = incidentsRestored,
                logsRestored = logsRestored,
                attachmentsRestored = attachmentsRestored,
                backupDateString = dateDisplay,
                message = "تمت استعادة البيانات بنجاح: $schoolsRestored مدرسة، $teachersRestored معلماً، $incidentsRestored واقعة، $tripsRestored رحلة، $leavesRestored إجازة، و$attachmentsRestored مرفقاً."
            )
        } catch (e: Exception) {
            e.printStackTrace()
            RestoreResult(
                success = false,
                message = "حدث خطأ أثناء استرجاع النسخة الاحتياطية: ${e.localizedMessage}"
            )
        }
    }
}
