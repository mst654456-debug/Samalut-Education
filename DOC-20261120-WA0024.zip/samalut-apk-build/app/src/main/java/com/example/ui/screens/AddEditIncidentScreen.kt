package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.components.FullScreenImageViewerDialog
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditIncidentScreen(
    initialSchoolName: String? = null,
    existingIncident: SecurityIncident? = null,
    schoolsList: List<School>,
    onSaveIncident: (SecurityIncident) -> Unit,
    onDeleteIncident: ((SecurityIncident) -> Unit)? = null,
    onBackClick: () -> Unit
) {
    var title by remember { mutableStateOf(existingIncident?.title ?: "") }
    var description by remember { mutableStateOf(existingIncident?.description ?: "") }
    var selectedSchool by remember {
        mutableStateOf(
            existingIncident?.schoolName
                ?: initialSchoolName
                ?: (schoolsList.firstOrNull()?.name ?: "مدرسة سمالوط الثانوية بنين")
        )
    }
    var partiesInvolved by remember { mutableStateOf(existingIncident?.partiesInvolved ?: "") }
    var actionTaken by remember { mutableStateOf(existingIncident?.actionTaken ?: "") }
    var status by remember { mutableStateOf(existingIncident?.status ?: IncidentStatus.IN_PROGRESS) }
    var imageUris by remember { mutableStateOf(existingIncident?.imageUris ?: emptyList()) }

    // State for full-screen photo viewer dialog
    var selectedPhotoForPreview by remember { mutableStateOf<String?>(null) }

    // State for delete confirmation dialog
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    val currentDate = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()) }
    val currentTime = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }

    var expandedSchoolDropdown by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Multiple Photos Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            imageUris = imageUris + uris.map { it.toString() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (existingIncident == null) "تسجيل واقعة أمنية جديدة" else "تعديل بيانات الواقعة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("incident_back_button")
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (existingIncident != null && onDeleteIncident != null) {
                        IconButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.testTag("incident_delete_top_button")
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "حذف الواقعة",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Validation Error Banner
            if (errorMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان الواقعة / الموضوع *") },
                placeholder = { Text("مثال: متابعة أمنية أو شكوى بمدرسة...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("incident_title_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // School Selector Dropdown
            ExposedDropdownMenuBox(
                expanded = expandedSchoolDropdown,
                onExpandedChange = { expandedSchoolDropdown = !expandedSchoolDropdown }
            ) {
                OutlinedTextField(
                    value = selectedSchool,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("المدرسة المعنية *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedSchoolDropdown) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("incident_school_select"),
                    shape = RoundedCornerShape(12.dp)
                )

                ExposedDropdownMenu(
                    expanded = expandedSchoolDropdown,
                    onDismissRequest = { expandedSchoolDropdown = false }
                ) {
                    schoolsList.forEach { school ->
                        DropdownMenuItem(
                            text = { Text(school.name) },
                            onClick = {
                                selectedSchool = school.name
                                expandedSchoolDropdown = false
                            }
                        )
                    }
                }
            }

            // Parties Involved
            OutlinedTextField(
                value = partiesInvolved,
                onValueChange = { partiesInvolved = it },
                label = { Text("الأطراف المعنية بالواقعة") },
                placeholder = { Text("الأطراف المشاركة أو مقدم البلاغ...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("incident_parties_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Incident Status Field (للاستخدام الإداري الداخلي فقط)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = EduBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "حالة الواقعة (للاستخدام الإداري الداخلي):",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IncidentStatus.values().forEach { st ->
                            val isSelected = status == st
                            val statusColor = when (st) {
                                IncidentStatus.RESOLVED -> StatusResolved
                                IncidentStatus.IN_PROGRESS -> StatusInProgress
                                IncidentStatus.CLOSED -> StatusClosed
                            }
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { status = st }
                                    .testTag("status_chip_${st.name}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) statusColor else statusColor.copy(alpha = 0.12f),
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.3f))
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                ) {
                                    Text(
                                        text = st.displayNameAr,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSelected) Color.White else statusColor
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Description Field
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("تفاصيل ووصف الواقعة *") },
                placeholder = { Text("سرد ما تم رصده من تفاصيل وأسباب وملابسات...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("incident_description_input"),
                minLines = 3,
                shape = RoundedCornerShape(12.dp)
            )

            // Action Taken
            OutlinedTextField(
                value = actionTaken,
                onValueChange = { actionTaken = it },
                label = { Text("الإجراء المتخذ من إدارة الأمن والمدرسة") },
                placeholder = { Text("مثال: توجيه لجنة متابعة، فحص الكاميرات، اتخاذ الإجراءات...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("incident_action_input"),
                minLines = 2,
                shape = RoundedCornerShape(12.dp)
            )

            // Multiple Photo Attachments Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "إرفاق صور المعاينة (${imageUris.size})",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "انقر على أي صورة لمعاينتها بحجم كامل",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_photos_button")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إرفاق صور", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    if (imageUris.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("incident_photos_preview_row")
                        ) {
                            items(imageUris) { uriStr ->
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                        .clickable { selectedPhotoForPreview = uriStr }
                                        .testTag("photo_thumbnail_${uriStr.hashCode()}")
                                ) {
                                    AsyncImage(
                                        model = uriStr,
                                        contentDescription = "معاينة صورة الواقعة",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )

                                    // Tap to inspect hint overlay
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(4.dp)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                            .size(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.ZoomIn,
                                            contentDescription = "معاينة",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    // (X) Button to delete attached photo before saving
                                    IconButton(
                                        onClick = { imageUris = imageUris.filter { it != uriStr } },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(26.dp)
                                            .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                            .testTag("delete_photo_${uriStr.hashCode()}")
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "حذف الصورة",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Supervisor Info Notice
            Surface(
                color = EduBlueLight,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = EduBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "التسجيل معتمد بمعرفة مسؤول أمن الإدارة: مستر مصطفى فرغلي",
                        style = MaterialTheme.typography.bodySmall,
                        color = EduBlueDark
                    )
                }
            }

            // Save / Update Button
            Button(
                onClick = {
                    if (title.isBlank()) {
                        errorMessage = "يرجى إدخال عنوان الواقعة"
                        return@Button
                    }
                    if (description.isBlank()) {
                        errorMessage = "يرجى كتابة تفاصيل ووصف الواقعة"
                        return@Button
                    }
                    errorMessage = null

                    val incident = SecurityIncident(
                        id = existingIncident?.id ?: 0,
                        title = title.trim(),
                        description = description.trim(),
                        schoolName = selectedSchool,
                        partiesInvolved = partiesInvolved.trim(),
                        actionTaken = actionTaken.trim(),
                        status = status,
                        dateString = existingIncident?.dateString ?: currentDate,
                        timeString = existingIncident?.timeString ?: currentTime,
                        supervisor = "مستر مصطفى فرغلي",
                        imageUris = imageUris
                    )
                    onSaveIncident(incident)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_incident_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (existingIncident == null) "حفظ وتسجيل الواقعة رسمياً" else "تحديث بيانات الواقعة",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            // Delete Incident Button (When Editing)
            if (existingIncident != null && onDeleteIncident != null) {
                OutlinedButton(
                    onClick = { showDeleteConfirmation = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("delete_incident_button"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "حذف الواقعة نهائياً من السجل",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Full Screen Image Viewer Modal Dialog
    if (selectedPhotoForPreview != null) {
        FullScreenImageViewerDialog(
            imageUri = selectedPhotoForPreview!!,
            onDismiss = { selectedPhotoForPreview = null }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirmation && existingIncident != null && onDeleteIncident != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = {
                Text(
                    text = "تأكيد حذف الواقعة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text("هل أنت متأكد من رغبتك في حذف واقعة '${existingIncident.title}' نهائياً من سجلات إدارة الأمن؟ لا يمكن التراجع عن هذا الإجراء.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmation = false
                        onDeleteIncident(existingIncident)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_incident_dialog_button")
                ) {
                    Text("حذف نهائياً")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirmation = false },
                    modifier = Modifier.testTag("cancel_delete_incident_dialog_button")
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}
