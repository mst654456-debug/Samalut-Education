package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.IncidentStatus
import com.example.data.model.SchoolStage
import com.example.data.model.VicePrincipal
import org.json.JSONArray
import org.json.JSONObject

class Converters {

    // SchoolStage Converters
    @TypeConverter
    fun fromSchoolStage(stage: SchoolStage): String = stage.name

    @TypeConverter
    fun toSchoolStage(value: String): SchoolStage = try {
        SchoolStage.valueOf(value)
    } catch (e: Exception) {
        SchoolStage.PRIMARY
    }

    // IncidentStatus Converters (تم الحل / جاري المتابعة / مغلقة)
    @TypeConverter
    fun fromIncidentStatus(status: IncidentStatus): String = status.name

    @TypeConverter
    fun toIncidentStatus(value: String): IncidentStatus = try {
        IncidentStatus.valueOf(value)
    } catch (e: Exception) {
        IncidentStatus.IN_PROGRESS
    }

    // List<String> Image URIs Converter for multiple incident photos
    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list == null || list.isEmpty()) return "[]"
        val jsonArray = JSONArray()
        for (item in list) {
            jsonArray.put(item)
        }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return try {
            val jsonArray = JSONArray(value)
            val list = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
            list
        } catch (e: Exception) {
            // Support backward comma-separated format if needed
            value.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
    }

    // List<VicePrincipal> Converter (from 1 to 4 vice principals)
    @TypeConverter
    fun fromVicePrincipalList(list: List<VicePrincipal>?): String {
        if (list == null || list.isEmpty()) return "[]"
        val jsonArray = JSONArray()
        for (vp in list) {
            val obj = JSONObject()
            obj.put("name", vp.name)
            obj.put("phone", vp.phone)
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toVicePrincipalList(value: String?): List<VicePrincipal> {
        if (value.isNullOrBlank()) return emptyList()
        return try {
            val jsonArray = JSONArray(value)
            val list = mutableListOf<VicePrincipal>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    VicePrincipal(
                        name = obj.optString("name", ""),
                        phone = obj.optString("phone", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }
}
