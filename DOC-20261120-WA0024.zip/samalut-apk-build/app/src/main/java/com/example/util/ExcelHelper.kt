package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.Teacher
import com.example.data.model.VicePrincipal
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.util.zip.ZipFile
import org.xmlpull.v1.XmlPullParser

object ExcelHelper {

    data class ImportResult<T>(
        val items: List<T>,
        val errors: List<String>,
        val totalProcessed: Int
    )

    /**
     * قراءة السطور والخلايا من ملف (يدعم صيغ XLSX الحقيقية وصيغ CSV و TXT)
     */
    fun readRowsFromUri(context: Context, uri: Uri): Pair<String, List<List<String>>> {
        val fileName = getFileNameFromUri(context, uri) ?: "ملف_بيانات"
        val tempFile = File(context.cacheDir, "temp_import_${System.currentTimeMillis()}.bin")

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return Pair(fileName, emptyList())

            val isZip = isZipFile(tempFile)
            val rows = if (isZip) {
                parseXlsxFile(tempFile)
            } else {
                val text = tempFile.readText(Charsets.UTF_8)
                parseTextToRows(text)
            }
            return Pair(fileName, rows)
        } catch (e: Exception) {
            return Pair(fileName, emptyList())
        } finally {
            tempFile.delete()
        }
    }

    /**
     * التحقق مما إذا كان الملف مضغوطاً بصيغة ZIP (وهي بنية ملفات XLSX الرسمية)
     */
    private fun isZipFile(file: File): Boolean {
        if (!file.exists() || file.length() < 4) return false
        return try {
            file.inputStream().use { input ->
                val b1 = input.read()
                val b2 = input.read()
                val b3 = input.read()
                val b4 = input.read()
                b1 == 0x50 && b2 == 0x4B && (b3 == 0x03 || b3 == 0x05 || b3 == 0x07) && (b4 == 0x04 || b4 == 0x06 || b4 == 0x08)
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * استخراج الصفوف والخلايا من مصنف Excel (XLSX) عبر قراءة sharedStrings و sheet1.xml
     */
    private fun parseXlsxFile(file: File): List<List<String>> {
        val zip = ZipFile(file)
        try {
            // 1. قراءة النصوص المشتركة SharedStrings
            val sharedStrings = mutableListOf<String>()
            val sharedStringsEntry = zip.getEntry("xl/sharedStrings.xml")
                ?: zip.entries().asSequence().firstOrNull { it.name.endsWith("sharedStrings.xml", ignoreCase = true) }

            if (sharedStringsEntry != null) {
                zip.getInputStream(sharedStringsEntry).use { input ->
                    val parser = android.util.Xml.newPullParser()
                    parser.setInput(input, "UTF-8")
                    var eventType = parser.eventType
                    var insideSi = false
                    val currentText = StringBuilder()

                    while (eventType != XmlPullParser.END_DOCUMENT) {
                        val tagName = parser.name
                        when (eventType) {
                            XmlPullParser.START_TAG -> {
                                if (tagName.equals("si", ignoreCase = true)) {
                                    insideSi = true
                                    currentText.clear()
                                }
                            }
                            XmlPullParser.TEXT -> {
                                if (insideSi) {
                                    currentText.append(parser.text)
                                }
                            }
                            XmlPullParser.END_TAG -> {
                                if (tagName.equals("si", ignoreCase = true)) {
                                    sharedStrings.add(currentText.toString())
                                    insideSi = false
                                }
                            }
                        }
                        eventType = parser.next()
                    }
                }
            }

            // 2. قراءة أول ورقة عمل (Worksheet Sheet1)
            val sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml")
                ?: zip.entries().asSequence().firstOrNull { it.name.contains("worksheets/sheet", ignoreCase = true) }
                ?: return emptyList()

            val allRows = mutableListOf<List<String>>()
            zip.getInputStream(sheetEntry).use { input ->
                val parser = android.util.Xml.newPullParser()
                parser.setInput(input, "UTF-8")
                var eventType = parser.eventType

                var currentRowCells = mutableMapOf<Int, String>()
                var currentCellCol = -1
                var currentCellType: String? = null
                var insideValue = false
                val cellValue = StringBuilder()

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    val tagName = parser.name
                    when (eventType) {
                        XmlPullParser.START_TAG -> {
                            when {
                                tagName.equals("row", ignoreCase = true) -> {
                                    currentRowCells = mutableMapOf()
                                }
                                tagName.equals("c", ignoreCase = true) -> {
                                    val cellRef = parser.getAttributeValue(null, "r") ?: ""
                                    currentCellCol = if (cellRef.isNotBlank()) {
                                        val letters = cellRef.takeWhile { it.isLetter() }
                                        columnNameToIndex(letters)
                                    } else {
                                        (currentRowCells.keys.maxOrNull() ?: -1) + 1
                                    }
                                    currentCellType = parser.getAttributeValue(null, "t")
                                    cellValue.clear()
                                }
                                tagName.equals("v", ignoreCase = true) || tagName.equals("t", ignoreCase = true) -> {
                                    insideValue = true
                                }
                            }
                        }
                        XmlPullParser.TEXT -> {
                            if (insideValue) {
                                cellValue.append(parser.text)
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            when {
                                tagName.equals("v", ignoreCase = true) || tagName.equals("t", ignoreCase = true) -> {
                                    insideValue = false
                                }
                                tagName.equals("c", ignoreCase = true) -> {
                                    val raw = cellValue.toString().trim()
                                    val finalStr = when (currentCellType) {
                                        "s" -> {
                                            val idx = raw.toIntOrNull()
                                            if (idx != null && idx in sharedStrings.indices) sharedStrings[idx] else raw
                                        }
                                        else -> raw
                                    }
                                    if (currentCellCol >= 0) {
                                        currentRowCells[currentCellCol] = finalStr
                                    }
                                }
                                tagName.equals("row", ignoreCase = true) -> {
                                    if (currentRowCells.isNotEmpty()) {
                                        val maxCol = currentRowCells.keys.maxOrNull() ?: 0
                                        val rowList = (0..maxCol).map { col -> currentRowCells[col] ?: "" }
                                        if (rowList.any { it.isNotBlank() }) {
                                            allRows.add(rowList)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    eventType = parser.next()
                }
            }
            return allRows
        } finally {
            zip.close()
        }
    }

    /**
     * تحويل رمز العمود في Excel مثل (A, B, Z, AA) إلى مؤشر رقمي مبدوء بـ 0
     */
    fun columnNameToIndex(colName: String): Int {
        var index = 0
        for (ch in colName.uppercase()) {
            if (ch in 'A'..'Z') {
                index = index * 26 + (ch - 'A' + 1)
            }
        }
        return if (index > 0) index - 1 else 0
    }

    /**
     * تحليل النص (CSV / TSV) إلى مصفوفة صفوف وخلايا
     */
    fun parseTextToRows(content: String): List<List<String>> {
        val lines = content.lines()
        val result = mutableListOf<List<String>>()
        for (line in lines) {
            if (line.isBlank()) continue
            val delimiter = when {
                line.contains("\t") -> '\t'
                line.contains(";") -> ';'
                else -> ','
            }
            result.add(parseCsvLine(line, delimiter))
        }
        return result
    }

    /**
     * تحليل سطر CSV مع دعم النصوص المحاطة بعلامات تنصيص
     */
    fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val tokens = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                c == delimiter && !inQuotes -> {
                    tokens.add(current.toString().trim())
                    current.clear()
                }
                else -> {
                    current.append(c)
                }
            }
            i++
        }
        tokens.add(current.toString().trim())
        return tokens
    }

    /**
     * قراءة واستيراد بيانات المدارس من الصفوف:
     * الأعمدة المعتمدة:
     * [الرقم المسلسل | اسم المدرسة | المرحلة | كود المدرسة | اسم المدير | هاتف المدير |
     *  اسم الوكيل | هاتف الوكيل | مسؤول الأمن | هاتف مسؤول الأمن | عدد الفصول |
     *  عدد العاملين | عدد الكاميرات | عدد المباني | عدد العمال | الملاحظات]
     */
    fun parseSchoolsFromRows(rows: List<List<String>>): ImportResult<School> {
        if (rows.isEmpty()) return ImportResult(emptyList(), emptyList(), 0)

        val schools = mutableListOf<School>()
        val errors = mutableListOf<String>()

        // فحص سطر الترويسة
        val firstRow = rows[0]
        val hasHeader = firstRow.any { col ->
            col.contains("المدرسة") || col.contains("اسم") || col.contains("كود") || col.contains("مرحل")
        }

        var idxSerial = -1
        var idxName = -1
        var idxStage = -1
        var idxCode = -1
        var idxPrincipalName = -1
        var idxPrincipalPhone = -1
        var idxVicePrincipalName = -1
        var idxVicePrincipalPhone = -1
        var idxSecurityOfficer = -1
        var idxSecurityPhone = -1
        var idxClassrooms = -1
        var idxStaff = -1
        var idxCameras = -1
        var idxBuildings = -1
        var idxWorkers = -1
        var idxNotes = -1

        if (hasHeader) {
            firstRow.forEachIndexed { i, colText ->
                val h = colText.trim()
                when {
                    h.contains("كود") -> idxCode = i
                    h.contains("مسلسل") || h == "م" -> idxSerial = i
                    h.contains("فصول") -> idxClassrooms = i
                    h.contains("كامير") -> idxCameras = i
                    h.contains("مبان") -> idxBuildings = i
                    h.contains("عمال") && !h.contains("عاملين") -> idxWorkers = i
                    h.contains("عاملين") || h.contains("معلمين") -> idxStaff = i
                    h.contains("ملاحظ") -> idxNotes = i
                    h.contains("مرحل") -> idxStage = i
                    h.contains("أمن") || h.contains("امن") -> {
                        if (h.contains("هاتف") || h.contains("تليفون") || h.contains("رقم") || h.contains("موبايل")) {
                            idxSecurityPhone = i
                        } else {
                            idxSecurityOfficer = i
                        }
                    }
                    h.contains("وكيل") -> {
                        if (h.contains("هاتف") || h.contains("تليفون") || h.contains("رقم") || h.contains("موبايل")) {
                            idxVicePrincipalPhone = i
                        } else {
                            idxVicePrincipalName = i
                        }
                    }
                    h.contains("مدير") -> {
                        if (h.contains("هاتف") || h.contains("تليفون") || h.contains("رقم") || h.contains("موبايل")) {
                            idxPrincipalPhone = i
                        } else {
                            idxPrincipalName = i
                        }
                    }
                    (h.contains("مدرسة") || h.contains("اسم")) && idxName == -1 -> idxName = i
                }
            }
        }

        // إذا لم يتم العثور على الترويسة بدقة، استخدام الترتيب الافتراضي المعتمد
        if (idxName == -1) {
            if (firstRow.size <= 8) {
                // الترتيب القديم المتوافق
                idxName = 0
                idxStage = 1
                idxClassrooms = 2
                idxStaff = 3
                idxPrincipalName = 4
                idxVicePrincipalName = 5
                idxNotes = 6
            } else {
                // الترتيب الجديد ذو الـ 16 عموداً
                idxSerial = 0
                idxName = 1
                idxStage = 2
                idxCode = 3
                idxPrincipalName = 4
                idxPrincipalPhone = 5
                idxVicePrincipalName = 6
                idxVicePrincipalPhone = 7
                idxSecurityOfficer = 8
                idxSecurityPhone = 9
                idxClassrooms = 10
                idxStaff = 11
                idxCameras = 12
                idxBuildings = 13
                idxWorkers = 14
                idxNotes = 15
            }
        }

        val startIndex = if (hasHeader) 1 else 0

        for (i in startIndex until rows.size) {
            val row = rows[i]
            if (row.isEmpty() || row.all { it.isBlank() }) continue

            try {
                val name = (if (idxName in row.indices) row[idxName] else "").trim()
                if (name.isBlank()) continue

                val serialNumber = (if (idxSerial in row.indices) row[idxSerial] else "").trim()
                val stageStr = (if (idxStage in row.indices) row[idxStage] else "").trim()
                val stage = SchoolStage.fromString(stageStr)
                val code = (if (idxCode in row.indices) row[idxCode] else "").trim()

                val principalName = (if (idxPrincipalName in row.indices) row[idxPrincipalName] else "").trim()
                val principalPhone = (if (idxPrincipalPhone in row.indices) row[idxPrincipalPhone] else "").trim()

                val vicePrincipalName = (if (idxVicePrincipalName in row.indices) row[idxVicePrincipalName] else "").trim()
                val vicePrincipalPhone = (if (idxVicePrincipalPhone in row.indices) row[idxVicePrincipalPhone] else "").trim()

                val securityOfficerName = (if (idxSecurityOfficer in row.indices) row[idxSecurityOfficer] else "").trim()
                val securityOfficerPhone = (if (idxSecurityPhone in row.indices) row[idxSecurityPhone] else "").trim()

                val classroomsCount = (if (idxClassrooms in row.indices) row[idxClassrooms].toIntOrNull() else null) ?: 0
                val staffCount = (if (idxStaff in row.indices) row[idxStaff].toIntOrNull() else null) ?: 0
                val camerasCount = (if (idxCameras in row.indices) row[idxCameras].toIntOrNull() else null) ?: 0
                val buildingsCount = (if (idxBuildings in row.indices) row[idxBuildings].toIntOrNull() else null) ?: 1
                val workersCount = (if (idxWorkers in row.indices) row[idxWorkers].toIntOrNull() else null) ?: 0
                val notes = (if (idxNotes in row.indices) row[idxNotes] else "").trim()

                val vps = if (vicePrincipalName.isNotBlank() || vicePrincipalPhone.isNotBlank()) {
                    listOf(VicePrincipal(name = vicePrincipalName, phone = vicePrincipalPhone))
                } else {
                    emptyList()
                }

                schools.add(
                    School(
                        governorate = "المنيا",
                        administration = "سمالوط التعليمية",
                        name = name,
                        code = code,
                        serialNumber = serialNumber,
                        stage = stage,
                        principalName = principalName,
                        principalPhone = principalPhone,
                        vicePrincipals = vps,
                        securityOfficerName = securityOfficerName,
                        securityOfficerPhone = securityOfficerPhone,
                        classroomsCount = classroomsCount,
                        teachersCount = staffCount,
                        workersCount = workersCount,
                        buildingsCount = buildingsCount,
                        extinguishersCount = 0,
                        camerasCount = camerasCount,
                        notes = notes
                    )
                )
            } catch (e: Exception) {
                errors.add("خطأ في السطر ${i + 1}: ${e.localizedMessage}")
            }
        }

        return ImportResult(schools, errors, rows.size - startIndex)
    }

    /**
     * استيراد شيت بيانات المدارس من النص
     */
    fun parseSchoolsFromText(content: String): ImportResult<School> {
        val rows = parseTextToRows(content)
        return parseSchoolsFromRows(rows)
    }

    /**
     * قراءة واستيراد بيانات المعلمين من الصفوف:
     * الأعمدة المعتمدة:
     * [م | الاسم | كود المعلم | الرقم القومي | اسم المدرسة | الوظيفة |
     *  العمل المكلف به | رقم التليفون | العنوان | الملاحظات]
     */
    fun parseTeachersFromRows(rows: List<List<String>>): ImportResult<Teacher> {
        if (rows.isEmpty()) return ImportResult(emptyList(), emptyList(), 0)

        val teachers = mutableListOf<Teacher>()
        val errors = mutableListOf<String>()

        val firstRow = rows[0]
        val hasHeader = firstRow.any { col ->
            col.contains("الاسم") || col.contains("معلم") || col.contains("المدرسة") || col.contains("القومي")
        }

        var idxName = -1
        var idxCode = -1
        var idxNationalId = -1
        var idxSchool = -1
        var idxJobTitle = -1
        var idxDuty = -1
        var idxPhone = -1
        var idxAddress = -1
        var idxNotes = -1

        if (hasHeader) {
            firstRow.forEachIndexed { i, colText ->
                val h = colText.trim()
                when {
                    h.contains("كود") -> idxCode = i
                    h.contains("قومي") -> idxNationalId = i
                    h.contains("مدرسة") -> idxSchool = i
                    h.contains("وظيفة") || h.contains("مسمى") -> idxJobTitle = i
                    h.contains("مكلف") || h.contains("تكليف") || h.contains("العمل") -> idxDuty = i
                    h.contains("تليفون") || h.contains("هاتف") || h.contains("موبايل") -> idxPhone = i
                    h.contains("عنوان") || h.contains("إقامة") -> idxAddress = i
                    h.contains("ملاحظ") -> idxNotes = i
                    h.contains("اسم") && !h.contains("مدرسة") && idxName == -1 -> idxName = i
                }
            }
        }

        // إذا لم تتحدد الأعمدة عبر الترويسة، استخدام الترتيب الافتراضي المعتمد
        if (idxName == -1) {
            if (firstRow.size <= 8 && firstRow.any { it.contains("المادة") || it.contains("تعيين") }) {
                // الترتيب القديم المتوافق
                idxName = 0
                idxSchool = 1
                idxJobTitle = 3
                idxPhone = 4
                idxNationalId = 5
            } else {
                // الترتيب الجديد ذو الـ 10 أعمدة
                idxName = 1
                idxCode = 2
                idxNationalId = 3
                idxSchool = 4
                idxJobTitle = 5
                idxDuty = 6
                idxPhone = 7
                idxAddress = 8
                idxNotes = 9
            }
        }

        val startIndex = if (hasHeader) 1 else 0

        for (i in startIndex until rows.size) {
            val row = rows[i]
            if (row.isEmpty() || row.all { it.isBlank() }) continue

            try {
                val name = (if (idxName in row.indices) row[idxName] else "").trim()
                if (name.isBlank()) continue

                val teacherCode = (if (idxCode in row.indices) row[idxCode] else "").trim()
                val nationalId = (if (idxNationalId in row.indices) row[idxNationalId] else "").trim()
                val schoolName = (if (idxSchool in row.indices) row[idxSchool] else "").trim().ifBlank { "مدرسة سمالوط" }
                val jobTitle = (if (idxJobTitle in row.indices) row[idxJobTitle] else "").trim().ifBlank { "معلم" }
                val assignedDuty = (if (idxDuty in row.indices) row[idxDuty] else "").trim()
                val phone = (if (idxPhone in row.indices) row[idxPhone] else "").trim()
                val address = (if (idxAddress in row.indices) row[idxAddress] else "").trim()
                val notes = (if (idxNotes in row.indices) row[idxNotes] else "").trim()

                teachers.add(
                    Teacher(
                        name = name,
                        teacherCode = teacherCode,
                        nationalId = nationalId,
                        schoolName = schoolName,
                        stage = SchoolStage.PRIMARY,
                        jobTitle = jobTitle,
                        assignedDuty = assignedDuty,
                        phone = phone,
                        address = address,
                        subject = "",
                        hireDate = "",
                        notes = notes,
                        attachedFiles = emptyList()
                    )
                )
            } catch (e: Exception) {
                errors.add("خطأ في السطر ${i + 1}: ${e.localizedMessage}")
            }
        }

        return ImportResult(teachers, errors, rows.size - startIndex)
    }

    /**
     * استيراد شيت بيانات المعلمين من النص
     */
    fun parseTeachersFromText(content: String): ImportResult<Teacher> {
        val rows = parseTextToRows(content)
        return parseTeachersFromRows(rows)
    }

    fun readContentFromUri(context: Context, uri: Uri): String? {
        return try {
            val (_, rows) = readRowsFromUri(context, uri)
            if (rows.isNotEmpty()) {
                rows.joinToString("\n") { it.joinToString(",") }
            } else {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                        reader.readText()
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String? {
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            return cursor.getString(nameIndex)
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
        return uri.lastPathSegment
    }

    /**
     * نموذج شيت Excel التجريبي للمدارس المتوافق مع الأعمدة الـ 16
     */
    fun getSampleSchoolsCsv(): String {
        return """الرقم المسلسل,اسم المدرسة,المرحلة,كود المدرسة,اسم المدير,هاتف المدير,اسم الوكيل,هاتف الوكيل,مسؤول الأمن,هاتف مسؤول الأمن,عدد الفصول,عدد العاملين,عدد الكاميرات,عدد المباني,عدد العمال,الملاحظات
1,مدرسة سمالوط الثانوية بنين,ثانوي عام,SCH-240101,أ/ محمد أحمد حسن,01011223344,أ/ رامي كمال,01222334455,أ/ حسن علي,01111223344,24,65,16,2,6,مبنى رئيسي ومبنى ملحق مجهز
2,مدرسة سمالوط الإعدادية بنات,إعدادي,SCH-240102,أ/ فاطمة إبراهيم,01144556677,أ/ سناء فؤاد,01099887766,أ/ سمير شوقي,01233445566,18,48,12,1,4,منظومة كاميرات متكاملة
3,مدرسة الشهيد كمال الابتدائية,ابتدائي,SCH-240103,أ/ علاء محمود,01200112233,أ/ منى عبد العزيز,01188776655,أ/ محمود ربيع,01055443322,20,52,8,1,5,تم فحص طفايات الحريق
4,مدرسة المستقبل الرسمية لغات,رياض أطفال,SCH-240104,أ/ إيمان صابر,01099881122,أ/ نهى كمال,01244556677,أ/ طارق سعيد,01133221100,12,32,10,1,3,قسم رياض أطفال مجهز
5,مدرسة سمالوط الفنية المتقدمة,ثانوي فني,SCH-240105,أ/ خالد ممدوح,01122339900,أ/ هاني صبحي,01066554433,أ/ عماد فهمي,01277889900,30,85,20,3,8,ورش ومعامل فنية مجهزة"""
    }

    /**
     * نموذج شيت Excel التجريبي للمعلمين المتوافق مع الأعمدة الـ 10
     */
    fun getSampleTeachersCsv(): String {
        return """م,الاسم,كود المعلم,الرقم القومي,اسم المدرسة,الوظيفة,العمل المكلف به,رقم التليفون,العنوان,الملاحظات
1,أ/ طارق محمود حسن,TCH-1001,28805151700981,مدرسة سمالوط الثانوية بنين,معلم خبير,مشرف أمن الدور الأول ولجنة السلامة,01011223344,مدينة سمالوط,مسؤول عن متابعة دفاتر الحضور
2,أ/ منى ربيع عبد السلام,TCH-1002,29107201700432,مدرسة سمالوط الإعدادية بنات,معلم أول أ,مشرفة طوارئ وإخلاء بالمبنى المدرسي,01144556677,قرية منقطين - سمالوط,عضو فريق إدارة الأزمات
3,أ/ ياسر صابر عبد العزيز,TCH-1003,28503101700763,مدرسة الشهيد كمال الابتدائية,أخصائي اجتماعي,مسؤول العلاقات والتدخل السريع,01233445566,سمالوط البلد,مسؤول الاتصال بالإدارة التعليمية
4,أ/ رانيا مصطفى كمال,TCH-1004,29509111700344,مدرسة المستقبل الرسمية لغات,معلمة لغة إنجليزية,مشرفة أمن فناء المدرسة,01099881122,قرية البيهو - سمالوط,متابعة دخول وخروج التلاميذ
5,أ/ شريف حسني إبراهيم,TCH-1005,28908141700125,مدرسة سمالوط الفنية المتقدمة,مهندس تدريب عملي,مسؤول أمن الورش المعملية والحريق,01122339900,قرية قلوصنا - سمالوط,خبير سلامة مهنية"""
    }
}
