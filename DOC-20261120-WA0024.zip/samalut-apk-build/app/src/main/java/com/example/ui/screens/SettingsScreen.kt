package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AdminConfig
import com.example.ui.theme.*
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    adminConfig: AdminConfig = AdminConfig(),
    onSaveAdminConfig: (directorate: String, administration: String, directorGeneral: String, securityOfficer: String) -> Unit,
    onResetData: () -> Unit,
    onLogout: () -> Unit,
    onBackClick: () -> Unit,
    isBackingUp: Boolean = false,
    lastBackupDate: String = "",
    isAutoBackupEnabled: Boolean = true,
    backupResult: com.example.util.BackupResult? = null,
    restoreResult: com.example.util.RestoreResult? = null,
    onToggleAutoBackup: (Boolean) -> Unit = {},
    onCreateBackupNow: () -> Unit = {},
    onRestoreBackup: (android.net.Uri) -> Unit = {},
    onDismissBackupResult: () -> Unit = {},
    onDismissRestoreResult: () -> Unit = {}
) {
    val context = LocalContext.current
    var showResetConfirm by remember { mutableStateOf(false) }

    // Admin Config Editing States
    var directorate by remember(adminConfig) { mutableStateOf(adminConfig.directorateName) }
    var administration by remember(adminConfig) { mutableStateOf(adminConfig.administrationName) }
    var directorGeneral by remember(adminConfig) { mutableStateOf(adminConfig.directorGeneralName) }
    var securityOfficer by remember(adminConfig) { mutableStateOf(adminConfig.securityOfficerName) }

    // Zip restore file picker
    val restorePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onRestoreBackup(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "الإعدادات والبيانات الإدارية",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Supervisor Profile Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .background(EduGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = EduBlueDark,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = adminConfig.securityOfficerName,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "مسؤول أمن الإدارة التعليمية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = EduBlue
                    )

                    Text(
                        text = "${adminConfig.directorateName} • ${adminConfig.administrationName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Editable Administrative Organization Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = EduBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تعديل البيانات الإدارية الثابتة والترويسة",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = "تُستخدم هذه البيانات رسمياً في ترويسة وتوقيعات كافة مستندات وتقارير PDF و Word:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = directorate,
                        onValueChange = { directorate = it },
                        label = { Text("اسم المديرية") },
                        leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = administration,
                        onValueChange = { administration = it },
                        label = { Text("اسم الإدارة التعليمية") },
                        leadingIcon = { Icon(Icons.Default.Domain, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = directorGeneral,
                        onValueChange = { directorGeneral = it },
                        label = { Text("اسم مدير عام الإدارة (جهة الاعتماد)") },
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = securityOfficer,
                        onValueChange = { securityOfficer = it },
                        label = { Text("اسم مسؤول أمن الإدارة (جهة الإعداد)") },
                        leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = EduGreen) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Button(
                        onClick = {
                            if (directorate.isBlank() || administration.isBlank() || directorGeneral.isBlank() || securityOfficer.isBlank()) {
                                Toast.makeText(context, "يرجى ملء كافة البيانات الإدارية", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            onSaveAdminConfig(
                                directorate.trim(),
                                administration.trim(),
                                directorGeneral.trim(),
                                securityOfficer.trim()
                            )
                            Toast.makeText(context, "تم حفظ وتحديث البيانات الإدارية بنجاح", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_admin_config_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ التعديلات الإدارية", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            // Periodic Auto-Backup & Data Recovery Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = EduBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "النسخ الاحتياطي الدوري وقاعدة البيانات (ZIP)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Auto-Backup Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "النسخ الاحتياطي التلقائي الأسبوعي",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "يعمل تلقائياً كل يوم جمعة في تمام الساعة 11:00 مساءً لتصدير كافة السجلات والمرفقات",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(
                            checked = isAutoBackupEnabled,
                            onCheckedChange = onToggleAutoBackup
                        )
                    }

                    if (lastBackupDate.isNotBlank()) {
                        Surface(
                            color = EduBlue.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = EduBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "آخر نسخة احتياطية تم إنشاؤها: $lastBackupDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = EduBlueDark
                                )
                            }
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Manual Create Backup Button
                    Button(
                        onClick = onCreateBackupNow,
                        enabled = !isBackingUp,
                        colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        if (isBackingUp) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري ضغط وتجهيز النسخة الاحتياطية...", color = Color.White)
                        } else {
                            Icon(Icons.Default.Archive, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إنشاء نسخة احتياطية الآن (تصدير ZIP كامل)", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    // Google Drive Export Button
                    FilledTonalButton(
                        onClick = {
                            val localFiles = com.example.util.BackupManager.getLocalBackupFiles(context)
                            if (localFiles.isNotEmpty()) {
                                com.example.util.BackupManager.exportToGoogleDrive(context, localFiles.first())
                            } else {
                                onCreateBackupNow()
                            }
                        },
                        enabled = !isBackingUp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1976D2).copy(alpha = 0.12f),
                            contentColor = Color(0xFF0D47A1)
                        )
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تصدير ورفع النسخة الاحتياطية إلى Google Drive ☁️", fontWeight = FontWeight.Bold)
                    }

                    // Google Drive / Local ZIP Restore Button
                    OutlinedButton(
                        onClick = { restorePicker.launch("application/zip") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = EduGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("استيراد واسترجاع من Google Drive / ZIP 🔄", fontWeight = FontWeight.Bold, color = EduGreen)
                    }
                }
            }

            // Operations & Hotlines Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "أرقام الطوارئ وغرفة العمليات",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    EmergencyRow(
                        title = "غرفة عمليات إدارة سمالوط",
                        number = "0863821040",
                        onCall = { WhatsAppHelper.makePhoneCall(context, "0863821040") }
                    )
                    EmergencyRow(
                        title = "شرطة النجدة سمالوط",
                        number = "122",
                        onCall = { WhatsAppHelper.makePhoneCall(context, "122") }
                    )
                    EmergencyRow(
                        title = "هيئة الإسعاف المصرية",
                        number = "123",
                        onCall = { WhatsAppHelper.makePhoneCall(context, "123") }
                    )
                    EmergencyRow(
                        title = "الحماية المدنية والإطفاء",
                        number = "180",
                        onCall = { WhatsAppHelper.makePhoneCall(context, "180") }
                    )
                }
            }

            // Sync and Storage Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "المزامنة وقاعدة البيانات",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudDone, contentDescription = null, tint = EduGreen)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "حالة العمل: متصل محلياً بقاعدة بيانات Room",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "تخزين دائم ومحمي يعمل بدون إنترنت تلقائياً",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { showResetConfirm = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = EduGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("استعادة البيانات الافتراضية لإدارة سمالوط")
                    }
                }
            }

            // Logout Button
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("logout_button")
            ) {
                Icon(Icons.Default.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تسجيل الخروج من المنظومة", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("استعادة البيانات الافتراضية") },
            text = { Text("سيتم إعادة تحميل بيانات مدارس ومعلمي سمالوط الافتراضية. هل ترغب بالاستمرار؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onResetData()
                    }
                ) {
                    Text("نعم، استعادة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Backup Result Dialog
    if (backupResult != null) {
        AlertDialog(
            onDismissRequest = onDismissBackupResult,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (backupResult.success) Icons.Default.CheckCircle else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (backupResult.success) EduGreen else SeverityHigh
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (backupResult.success) "تم إنشاء النسخة الاحتياطية" else "فشل النسخ الاحتياطي")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(backupResult.message)
                    if (backupResult.success) {
                        Text(
                            text = "الإحصائيات:\n• المدارس: ${backupResult.schoolsCount}\n• المعلمون: ${backupResult.teachersCount}\n• الوقائع: ${backupResult.incidentsCount}\n• المرفقات: ${backupResult.attachmentsCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                if (backupResult.success && backupResult.zipPath.isNotBlank()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = {
                                com.example.util.BackupManager.exportToGoogleDrive(context, java.io.File(backupResult.zipPath))
                                onDismissBackupResult()
                            }
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("رفع لـ Drive")
                        }
                        Button(
                            onClick = {
                                com.example.util.BackupManager.shareBackupFile(context, java.io.File(backupResult.zipPath))
                                onDismissBackupResult()
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة ZIP")
                        }
                    }
                } else {
                    Button(onClick = onDismissBackupResult) {
                        Text("حسناً")
                    }
                }
            },
            dismissButton = {
                if (backupResult.success && backupResult.zipPath.isNotBlank()) {
                    TextButton(onClick = onDismissBackupResult) {
                        Text("إغلاق")
                    }
                }
            }
        )
    }

    // Restore Result Dialog
    if (restoreResult != null) {
        AlertDialog(
            onDismissRequest = onDismissRestoreResult,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (restoreResult.success) Icons.Default.CheckCircle else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (restoreResult.success) EduGreen else SeverityHigh
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (restoreResult.success) "تمت استعادة البيانات بنجاح" else "فشل الاسترجاع")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(restoreResult.message)
                    if (restoreResult.success) {
                        Text(
                            text = "البيانات المستعادة:\n• المدارس: ${restoreResult.schoolsCount}\n• المعلمون: ${restoreResult.teachersCount}\n• الوقائع: ${restoreResult.incidentsCount}\n• المرفقات: ${restoreResult.attachmentsRestored}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = onDismissRestoreResult) {
                    Text("حسناً")
                }
            }
        )
    }
}

@Composable
fun EmergencyRow(
    title: String,
    number: String,
    onCall: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(text = number, style = MaterialTheme.typography.bodySmall, color = EduBlue)
        }
        IconButton(onClick = onCall) {
            Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = EduGreen)
        }
    }
}
