package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.ui.components.SchoolCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolsScreen(
    schools: List<School>,
    searchQuery: String,
    selectedStage: SchoolStage?,
    onSearchChange: (String) -> Unit,
    onStageSelect: (SchoolStage?) -> Unit,
    onAddSchool: (School) -> Unit,
    onUpdateSchool: (School) -> Unit,
    onDeleteSchool: (School) -> Unit,
    onSchoolClick: (Long) -> Unit,
    onBackClick: () -> Unit
) {
    var isStageMenuExpanded by remember { mutableStateOf(false) }
    var showAddSchoolDialog by remember { mutableStateOf(false) }
    var schoolToEdit by remember { mutableStateOf<School?>(null) }

    if (showAddSchoolDialog || schoolToEdit != null) {
        AddEditSchoolDialog(
            schoolToEdit = schoolToEdit,
            onDismiss = {
                showAddSchoolDialog = false
                schoolToEdit = null
            },
            onSaveSchool = { savedSchool ->
                if (savedSchool.id > 0) {
                    onUpdateSchool(savedSchool)
                } else {
                    onAddSchool(savedSchool)
                }
                showAddSchoolDialog = false
                schoolToEdit = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "مدارس إدارة سمالوط التعليمية",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "محافظة المنيا • قسم الأمن",
                            style = MaterialTheme.typography.bodySmall,
                            color = EduGold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        schoolToEdit = null
                        showAddSchoolDialog = true
                    }) {
                        Icon(Icons.Default.AddBusiness, contentDescription = "إضافة مدرسة", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    schoolToEdit = null
                    showAddSchoolDialog = true
                },
                containerColor = EduGreen,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.AddBusiness, contentDescription = null) },
                text = { Text("إضافة مدرسة جديدة", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_schools_add_school")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Stage Filter Dropdown Menu (استبدال الأزرار بقائمة منسدلة واحدة)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = isStageMenuExpanded,
                        onExpandedChange = { isStageMenuExpanded = !isStageMenuExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedStage?.displayNameAr ?: "جميع المراحل التعليمية (الكل)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("فلترة حسب المرحلة التعليمية") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStageMenuExpanded) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Category,
                                    contentDescription = null,
                                    tint = EduBlue
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("dropdown_filter_schools_stage")
                        )

                        ExposedDropdownMenu(
                            expanded = isStageMenuExpanded,
                            onDismissRequest = { isStageMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "جميع المراحل التعليمية (الكل)",
                                        fontWeight = if (selectedStage == null) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedStage == null) EduBlue else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    onStageSelect(null)
                                    isStageMenuExpanded = false
                                }
                            )

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                            SchoolStage.values().forEach { stage ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = stage.displayNameAr,
                                            fontWeight = if (selectedStage == stage) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedStage == stage) EduBlue else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    onClick = {
                                        onStageSelect(stage)
                                        isStageMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Search Bar
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_search_field"),
                        placeholder = { Text("بحث باسم المدرسة أو المدير أو العنوان...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EduBlue) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Schools List
            if (schools.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد مدارس مطابقة لبحثك في المرحلة المحددة",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FilledTonalButton(onClick = {
                            onStageSelect(null)
                            onSearchChange("")
                        }) {
                            Text("عرض جميع المدارس")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(schools, key = { it.id }) { school ->
                        SchoolCard(
                            school = school,
                            onSchoolClick = { onSchoolClick(school.id) },
                            onEditSchool = { schoolToEdit = school },
                            onDeleteSchool = { onDeleteSchool(school) },
                            onUpdateSchool = { onUpdateSchool(it) }
                        )
                    }
                }
            }
        }
    }
}
