package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.DailyLogEntry
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.model.VicePrincipal
import com.example.data.model.SchoolTripEntity
import com.example.data.model.TeacherLeaveEntity
import com.example.data.model.TeacherPenaltyEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        School::class,
        Teacher::class,
        SecurityIncident::class,
        DailyLogEntry::class,
        TeacherLeaveEntity::class,
        TeacherPenaltyEntity::class,
        SchoolTripEntity::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao
    abstract fun teacherDao(): TeacherDao
    abstract fun securityIncidentDao(): SecurityIncidentDao
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun teacherLeaveDao(): TeacherLeaveDao
    abstract fun teacherPenaltyDao(): TeacherPenaltyDao
    abstract fun schoolTripDao(): SchoolTripDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "samalut_security_db"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }
    }
}

suspend fun populateInitialData(database: AppDatabase) {
    val schoolDao = database.schoolDao()
    val teacherDao = database.teacherDao()
    val incidentDao = database.securityIncidentDao()
    val logDao = database.dailyLogDao()

    if (schoolDao.getCount() == 0) {
        val sampleSchools = listOf(
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة سمالوط الثانوية بنين",
                code = "SEC-SAM-101",
                serialNumber = "01",
                stage = SchoolStage.GENERAL_SECONDARY,
                principalName = "أ/ عادل عبد المجيد",
                principalPhone = "01001234567",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ طارق عبد الله", phone = "01098765432"),
                    VicePrincipal(name = "أ/ محمد عبد السميع", phone = "01123456789")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 28,
                teachersCount = 82,
                workersCount = 10,
                buildingsCount = 3,
                extinguishersCount = 14,
                camerasCount = 16,
                address = "شارع الجمهورية - بندر سمالوط",
                phone = "0863821040",
                notes = "مدرسة كبرى بها 1400 طالب، تحتاج متابعة أمنية عند الانصراف"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة سمالوط الثانوية بنات",
                code = "SEC-SAM-102",
                serialNumber = "02",
                stage = SchoolStage.GENERAL_SECONDARY,
                principalName = "أ/ نادية صادق إبراهيم",
                principalPhone = "01289012345",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ منال رفعت", phone = "01234567890")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 26,
                teachersCount = 75,
                workersCount = 10,
                buildingsCount = 2,
                extinguishersCount = 12,
                camerasCount = 12,
                address = "حي غرب - بجوار الإدارة التعليمية، سمالوط",
                phone = "0863823412",
                notes = "انضباط عالي، كاميرات مراقبة على البوابات الرئيسية"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة سمالوط الميكانيكية العسكرية",
                code = "TECH-SAM-201",
                serialNumber = "03",
                stage = SchoolStage.TECHNICAL_SECONDARY,
                principalName = "أ/ محمود فرغل",
                principalPhone = "01144556677",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ سامي محروس", phone = "01199887766"),
                    VicePrincipal(name = "أ/ علي رجب", phone = "01011223344")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 30,
                teachersCount = 90,
                workersCount = 15,
                buildingsCount = 4,
                extinguishersCount = 24,
                camerasCount = 20,
                address = "طريق مصر أسوان الزراعي - سمالوط",
                phone = "0863845011",
                notes = "ورش عملية ومعدات تحتاج تأمين وقائي ضد الحريق"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة سمالوط الإعدادية بنين",
                code = "PREP-SAM-301",
                serialNumber = "04",
                stage = SchoolStage.PREPARATORY,
                principalName = "أ/ ممدوح فوزي مرقص",
                principalPhone = "01099887766",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ جمال حميدة", phone = "01223344556")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 24,
                teachersCount = 66,
                workersCount = 8,
                buildingsCount = 2,
                extinguishersCount = 10,
                camerasCount = 8,
                address = "شارع المدارس - سمالوط",
                phone = "0863822189",
                notes = "كثافة طلابية عالية في الفصول"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة الشهيد أحمد كمال الابتدائية",
                code = "PRI-SAM-401",
                serialNumber = "05",
                stage = SchoolStage.PRIMARY,
                principalName = "أ/ حسام الدين لطفي",
                principalPhone = "01155443322",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ سميحة نجيب", phone = "01088776655")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 20,
                teachersCount = 55,
                workersCount = 7,
                buildingsCount = 2,
                extinguishersCount = 8,
                camerasCount = 6,
                address = "شارع المحطة - سمالوط",
                phone = "0863820455",
                notes = "تأمين خروج التلاميذ لمنع التدافع أمام الطريق السريع"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "روضة سمالوط الرسمية للغات",
                code = "KG-SAM-501",
                serialNumber = "06",
                stage = SchoolStage.KINDERGARTEN,
                principalName = "أ/ وفاء عبد الحميد",
                principalPhone = "01277665544",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ ريهام عزمي", phone = "01122334455")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 8,
                teachersCount = 18,
                workersCount = 4,
                buildingsCount = 1,
                extinguishersCount = 6,
                camerasCount = 8,
                address = "بندر سمالوط",
                phone = "0863829011",
                notes = "ألعاب خارجية مؤمنة وبوابات أطفال خاصة"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة التوفيقية للتعليم المجتمعي",
                code = "COM-SAM-601",
                serialNumber = "07",
                stage = SchoolStage.COMMUNITY_EDUCATION,
                principalName = "أ/ كمال سيد عبد الوهاب",
                principalPhone = "01066778899",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ مروان صبحي", phone = "01033445566")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 6,
                teachersCount = 12,
                workersCount = 2,
                buildingsCount = 1,
                extinguishersCount = 4,
                camerasCount = 4,
                address = "قرية التوفيقية - سمالوط",
                phone = "0863866100",
                notes = "فصول متعددة المستويات لخدمة القرية"
            ),
            School(
                governorate = "المنيا",
                administration = "سمالوط التعليمية",
                name = "مدرسة سان مارك الخاصة بسمالوط",
                code = "PRV-SAM-701",
                serialNumber = "08",
                stage = SchoolStage.PRIVATE_SCHOOLS,
                principalName = "أ/ رمسيس حليم عطالله",
                principalPhone = "01201234567",
                vicePrincipals = listOf(
                    VicePrincipal(name = "أ/ ماريان وجيه", phone = "01255667788")
                ),
                securityOfficerName = "مستر مصطفى فرغلي",
                securityOfficerPhone = "01005556677",
                classroomsCount = 18,
                teachersCount = 46,
                workersCount = 8,
                buildingsCount = 2,
                extinguishersCount = 12,
                camerasCount = 14,
                address = "شارع الجيش - سمالوط",
                phone = "0863821123",
                notes = "حالة أمنية مستقرة ومنظومة مراقبة حديثة"
            )
        )
        schoolDao.insertSchools(sampleSchools)
    }

    if (teacherDao.getCount() == 0) {
        val sampleTeachers = listOf(
            Teacher(
                name = "أ/ أحمد محمود الشريف",
                teacherCode = "T-1001",
                schoolName = "مدرسة سمالوط الثانوية بنين",
                stage = SchoolStage.GENERAL_SECONDARY,
                jobTitle = "معلم خبير رياضيات",
                assignedDuty = "مشرف عام جناح أ + عضو لجنة الأمن والسلامة",
                phone = "01004567891",
                nationalId = "28504121700112",
                subject = "رياضيات",
                hireDate = "2008/10/01",
                address = "سمالوط - حي الزهور",
                notes = "معلم متميز وملتزم بضوابط الأمن المدرسي"
            ),
            Teacher(
                name = "أ/ محمد كمال الدين عبد الباقي",
                teacherCode = "T-1002",
                schoolName = "مدرسة سمالوط الثانوية بنين",
                stage = SchoolStage.GENERAL_SECONDARY,
                jobTitle = "أخصائي اجتماعي أول",
                assignedDuty = "مسؤول متابعة سلوك الطلاب والانضباط المدرسي",
                phone = "01123456780",
                nationalId = "28902041700445",
                subject = "تربية اجتماعية",
                hireDate = "2012/03/15",
                address = "سمالوط - شارع الثورة",
                notes = "تنسيق دائم مع قسم أمن الإدارة"
            ),
            Teacher(
                name = "أ/ فاطمة حسن الزهراء",
                teacherCode = "T-1003",
                schoolName = "مدرسة سمالوط الثانوية بنات",
                stage = SchoolStage.GENERAL_SECONDARY,
                jobTitle = "معلم أول أ فيزياء",
                assignedDuty = "مشرفة معمل العلوم والأجهزة الوقائية",
                phone = "01289012345",
                nationalId = "28706181700321",
                subject = "فيزياء",
                hireDate = "2010/09/01",
                address = "سمالوط - شارع المستشفى",
                notes = "إشراف على مخارج الطوارئ بالمعمل"
            ),
            Teacher(
                name = "أ/ هشام صبحي عبد الله",
                teacherCode = "T-1004",
                schoolName = "مدرسة سمالوط الإعدادية بنين",
                stage = SchoolStage.PREPARATORY,
                jobTitle = "معلم لغة عربية",
                assignedDuty = "مشرف فناء المدرسة أثناء الفسحة وانصراف الطلاب",
                phone = "01099887766",
                nationalId = "29201011700876",
                subject = "لغة عربية",
                hireDate = "2016/11/01",
                address = "قرية التوفيقية - سمالوط"
            ),
            Teacher(
                name = "أ/ عبد الله مسعود علي",
                teacherCode = "T-1005",
                schoolName = "مدرسة الشهيد أحمد كمال الابتدائية",
                stage = SchoolStage.PRIMARY,
                jobTitle = "معلم دراسات اجتماعية",
                assignedDuty = "مسؤول استقبال التلاميذ صباحاً وتنظيم الطابور",
                phone = "01155443322",
                nationalId = "29405061700654",
                subject = "دراسات اجتماعية",
                hireDate = "2018/02/01",
                address = "سمالوط - شارع السلام"
            )
        )
        teacherDao.insertTeachers(sampleTeachers)
    }

    if (incidentDao.getCount() == 0) {
        val sampleIncidents = listOf(
            SecurityIncident(
                title = "مشادة وتدافع بين طلاب بالفسحة",
                description = "حدوث مشادة كلامية تطورت إلى تدافع بين طلاب الصف الأول الثانوي أثناء فترة الفسحة بفناء المدرسة، وتدخل الأخصائي الاجتماعي وإدارة الأمن فوراً.",
                schoolName = "مدرسة سمالوط الثانوية بنين",
                partiesInvolved = "الطالب يوسف محمود x الطالب عمر مصطفى",
                actionTaken = "تم اصطحاب الطلاب لمكتب الأمن والملاحظة، واستدعاء وليي الأمر وأخذ إقرار كتابي بالانضباط والتصالح بالتراضي.",
                status = IncidentStatus.RESOLVED,
                dateString = "2026/10/14",
                timeString = "11:20",
                supervisor = "مستر مصطفى فرغلي",
                imageUris = emptyList()
            ),
            SecurityIncident(
                title = "شكوى ولي أمر بشأن معاملة صفية",
                description = "حضور ولي أمر طالب بالصف الثاني الإعدادي معترضاً على درجة النشاط ومطالباً بمقابلة مدير المدرسة.",
                schoolName = "مدرسة سمالوط الإعدادية بنين",
                partiesInvolved = "ولي الأمر أحمد عادل x معلم المادة أ/ هشام صبحي",
                actionTaken = "استقبال ولي الأمر بمعرفة مسؤول الأمن وإدارة المدرسة وشرح آلية التقييم، وتفهم ولي الأمر وحل الموضوع ودياً.",
                status = IncidentStatus.CLOSED,
                dateString = "2026/10/13",
                timeString = "09:45",
                supervisor = "مستر مصطفى فرغلي",
                imageUris = emptyList()
            ),
            SecurityIncident(
                title = "متابعة أمان البوابة الخارجية وقت الانصراف",
                description = "تجمع لبعض الشباب غير المنتسبين للمدرسة أمام البوابة الخارجية وقت خروج الطلاب.",
                schoolName = "مدرسة سمالوط الميكانيكية العسكرية",
                partiesInvolved = "تجمعات شبابية أمام السور الخارجي",
                actionTaken = "التواصل الفوري مع نقطة الشرطة والدورية الميدانية لتأمين المحيط وفض التجمعات حتى انصراف كافة الطلاب بسلام.",
                status = IncidentStatus.IN_PROGRESS,
                dateString = "2026/10/12",
                timeString = "14:10",
                supervisor = "مستر مصطفى فرغلي",
                imageUris = emptyList()
            )
        )
        for (incident in sampleIncidents) {
            incidentDao.insertIncident(incident)
        }
    }

    val sampleLogs = listOf(
        DailyLogEntry(
            dateString = "2026/10/15",
            schoolName = "مدرسة سمالوط الثانوية بنين",
            teacherName = "أ/ أحمد محمود الشريف",
            note = "مرور ميداني صباحي للتأكد من انتظام طابور الصباح وخلو الفناء من أي معوقات أمنية.",
            supervisor = "مستر مصطفى فرغلي"
        ),
        DailyLogEntry(
            dateString = "2026/10/15",
            schoolName = "مدرسة الشهيد أحمد كمال الابتدائية",
            teacherName = "أ/ عبد الله مسعود علي",
            note = "متابعة تنظيم دخول التلاميذ صباحاً مع مشرفي الأدوار وسلامة مخارج الطوارئ ومطافئ الحريق.",
            supervisor = "مستر مصطفى فرغلي"
        )
    )
    for (log in sampleLogs) {
        logDao.insertLog(log)
    }
}
