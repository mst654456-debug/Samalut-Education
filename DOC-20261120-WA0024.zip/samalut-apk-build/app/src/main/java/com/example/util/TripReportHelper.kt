package com.example.util

import android.content.Context
import android.content.Intent
import com.example.data.model.SchoolTripEntity
import com.example.data.preferences.AdminConfig

object TripReportHelper {

    fun generateTripItineraryText(trip: SchoolTripEntity, adminConfig: AdminConfig): String {
        val supervisorsList = if (trip.supervisors.isNotEmpty()) {
            trip.supervisors.mapIndexed { idx, s -> "  ${idx + 1}. $s" }.joinToString("\n")
        } else {
            "  هيئة الإشراف المدرسية المعتمدة"
        }

        return """
========================================
${adminConfig.directorateName}
${adminConfig.administrationName}
قسم الأمن والحماية المدنية
========================================
بيان خط سير وتأمين رحلة مدرسية رسمية
========================================

• المدرسة المنظمة: ${trip.schoolName}
• وجهة ومكان الرحلة: ${trip.destination}
• موعد وتاريخ الرحلة: ${trip.tripDate}
• ساعة التجمع والانطلاق: ${trip.assemblyTime}
• عدد الطلاب المشاركين: ${trip.studentsCount} طالب

مشرفو الرحلة من معلمي المدرسة:
$supervisorsList

بيانات وسيلة النقل المعتمدة:
• شركة النقل: ${trip.transportCompany.ifBlank { "شركة نقل سياحي مرخصة" }}
• بيانات الأتوبيس والسائق: ${trip.busNumber.ifBlank { "تم الفحص الأمني والسلامة" }}

خط سير الرحلة المحدد:
${trip.routePlan.ifBlank { "الانطلاق من مقر المدرسة ثم التوجه المباشر إلى ${trip.destination} والالتزام بالبرنامج والعودة قبل حلول المساء." }}

التعليمات والاشتراطات الأمنية الواجب اتباعها:
${trip.securityInstructions}

حالة الاعتماد الأمني: ${trip.approvalStatus}

----------------------------------------
يعتمد،
مسؤول أمن الإدارة التعليمية: ${adminConfig.securityOfficerName}
مدير عام الإدارة التعليمية: ${adminConfig.directorGeneralName}
========================================
""".trimIndent()
    }

    fun shareTripItinerary(context: Context, trip: SchoolTripEntity, adminConfig: AdminConfig) {
        val text = generateTripItineraryText(trip, adminConfig)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "بيان خط سير وتأمين رحلة: ${trip.schoolName} - ${trip.destination}")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(sendIntent, "مشاركة / طباعة بيان خط سير الرحلة"))
    }
}
