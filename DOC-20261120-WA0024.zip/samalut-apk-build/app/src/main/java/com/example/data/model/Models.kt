package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * المراحل التعليمية المعتمدة:
 * رياض أطفال، ابتدائي، إعدادي، ثانوي عام، ثانوي فني، تعليم مجتمعي، مدارس خاصة
 */
enum class SchoolStage(val displayNameAr: String) {
    KINDERGARTEN("رياض أطفال"),
    PRIMARY("ابتدائي"),
    PREPARATORY("إعدادي"),
    GENERAL_SECONDARY("ثانوي عام"),
    TECHNICAL_SECONDARY("ثانوي فني"),
    COMMUNITY_EDUCATION("تعليم مجتمعي"),
    PRIVATE_SCHOOLS("مدارس خاصة");

    companion object {
        fun fromString(str: String): SchoolStage {
            return when {
                str.contains("رياض") || str.contains("أطفال") || str.contains("اطفال") || str.contains("kg", ignoreCase = true) -> KINDERGARTEN
                str.contains("مجتمع") -> COMMUNITY_EDUCATION
                str.contains("خاص") -> PRIVATE_SCHOOLS
                str.contains("فني") || str.contains("صناع") || str.contains("تجار") || str.contains("زراع") -> TECHNICAL_SECONDARY
                str.contains("ثانو") || str.contains("عام") -> GENERAL_SECONDARY
                str.contains("إعداد") || str.contains("اعداد") -> PREPARATORY
                str.contains("ابتدائ") -> PRIMARY
                else -> PRIMARY
            }
        }
    }
}

/**
 * نموذج بيانات الوكيل (يدعم من 1 إلى 4 وكلاء)
 */
data class VicePrincipal(
    val name: String = "",
    val phone: String = ""
)

/**
 * حالة الحدث / الواقعة: (تم الحل / جاري المتابعة / مغلقة)
 */
enum class IncidentStatus(val displayNameAr: String) {
    RESOLVED("تم الحل"),
    IN_PROGRESS("جاري المتابعة"),
    CLOSED("مغلقة");

    companion object {
        fun fromString(str: String): IncidentStatus {
            return when {
                str.contains("حل") -> RESOLVED
                str.contains("مغلق") -> CLOSED
                else -> IN_PROGRESS
            }
        }
    }
}

/**
 * جدول المدارس (SchoolEntity / School)
 */
@Entity(tableName = "schools")
data class School(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val governorate: String = "المنيا",
    val administration: String = "سمالوط التعليمية",
    val name: String,
    val code: String = "", // كود المدرسة
    val serialNumber: String = "", // الرقم المسلسل
    val stage: SchoolStage,
    // بيانات الإدارة المدرسية
    val principalName: String = "",
    val principalPhone: String = "",
    val vicePrincipals: List<VicePrincipal> = emptyList(),
    val securityOfficerName: String = "",
    val securityOfficerPhone: String = "",
    // بيانات التجهيزات والأعداد
    val classroomsCount: Int = 0,
    val teachersCount: Int = 0,
    val workersCount: Int = 0,
    val buildingsCount: Int = 0,
    val extinguishersCount: Int = 0,
    val camerasCount: Int = 0,
    // بيانات إضافية
    val address: String = "",
    val phone: String = "",
    val notes: String = "", // الملاحظات العامة
    val attachedFiles: List<String> = emptyList() // إرفاق مستندات وملفات PDF وصور خاصة بالمدرسة
) {
    // التوافقية مع الحقول السابقة في الواجهات القديمة إن وجدت
    val staffCount: Int get() = teachersCount + workersCount
    val vicePrincipalName: String get() = vicePrincipals.firstOrNull()?.name ?: ""
}

// الاسم المستعار SchoolEntity لتطابق التسمية المطلوبة بالكامل
typealias SchoolEntity = School

/**
 * جدول المعلمين والعاملين
 */
@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val teacherCode: String = "", // كود المعلم
    val nationalId: String = "", // الرقم القومي
    val schoolName: String, // المدرسة التابع لها
    val stage: SchoolStage, // المرحلة
    val jobTitle: String = "معلم", // الوظيفة
    val assignedDuty: String = "", // العمل المكلف به داخل المدرسة
    val phone: String = "", // رقم التليفون
    val address: String = "", // العنوان
    val subject: String = "", // المادة / التخصص
    val hireDate: String = "", // تاريخ التعيين
    val notes: String = "", // الملاحظات
    val attachedFiles: List<String> = emptyList() // إرفاق صور ومستندات PDF
)

/**
 * جدول الأحداث والوقائع (EventEntity / SecurityIncident)
 * تم حذف: (مستوى الخطورة، نوع التقرير، تصنيف طالب/طالب، إيميل مسؤول الأمن)
 * الاحتفاظ بحقل حالة الحدث داخلياً (تم الحل / جاري المتابعة / مغلقة)
 * دعم إرفاق صور متعددة للواقعة List<String>
 */
@Entity(tableName = "incidents")
data class SecurityIncident(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val schoolName: String,
    val partiesInvolved: String = "",
    val actionTaken: String = "",
    val status: IncidentStatus = IncidentStatus.IN_PROGRESS,
    val dateString: String = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()),
    val timeString: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
    val timestamp: Long = System.currentTimeMillis(),
    val supervisor: String = "مستر مصطفى فرغلي",
    val imageUris: List<String> = emptyList()
) {
    // التوافقية مع الحقول القديمة التي تطلب مسار صورة وحيد
    val imageUri: String? get() = imageUris.firstOrNull()
}

// الاسم المستعار EventEntity لتطابق التسمية المطلوبة
typealias EventEntity = SecurityIncident

/**
 * سجل المرور اليومي
 */
@Entity(tableName = "daily_logs")
data class DailyLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()),
    val schoolName: String = "",
    val teacherName: String = "",
    val note: String,
    val supervisor: String = "مستر مصطفى فرغلي",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * سجل إجازات المعلمين (Teacher Leaves)
 */
@Entity(tableName = "teacher_leaves")
data class TeacherLeaveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teacherId: Long = 0,
    val teacherName: String,
    val schoolName: String,
    val leaveType: String, // اعتيادي، عارضة، مرضي، وضع، رعاية طفل، خاصة بدون مرتب، أخرى
    val startDate: String, // YYYY/MM/DD
    val endDate: String,   // YYYY/MM/DD
    val daysCount: Int = 1,
    val destination: String = "داخل القطر", // داخل القطر / خارج القطر وتحديد المكان
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val isCurrentlyActive: Boolean
        get() {
            return try {
                val formats = listOf(
                    "yyyy/MM/dd", "dd/MM/yyyy", "dd / MM / yyyy",
                    "yyyy-MM-dd", "dd-MM-yyyy", "d/M/yyyy", "yyyy/M/d"
                )
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                val today = cal.time

                fun parseDate(dStr: String): java.util.Date? {
                    val clean = dStr.trim()
                    for (fmt in formats) {
                        try {
                            val sdf = SimpleDateFormat(fmt, Locale.US).apply { isLenient = true }
                            val parsed = sdf.parse(clean)
                            if (parsed != null) return parsed
                        } catch (_: Exception) {}
                    }
                    return null
                }

                val start = parseDate(startDate) ?: return false
                val end = parseDate(endDate) ?: return false
                !today.before(start) && !today.after(end)
            } catch (e: Exception) {
                false
            }
        }
}

typealias TeacherLeave = TeacherLeaveEntity

/**
 * سجل الجزاءات والخصومات (Teacher Penalties)
 */
@Entity(tableName = "teacher_penalties")
data class TeacherPenaltyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teacherId: Long = 0,
    val teacherName: String,
    val schoolName: String,
    val penaltyType: String, // إنذار، لفت نظر، خصم من الراتب، تأخير، إيقاف عن العمل
    val daysDeducted: Int = 0, // عدد الأيام في حالة الخصم
    val reason: String, // سبب وتفاصيل الجزاء
    val issuingAuthority: String = "الشؤون القانونية بالإدارة", // الجهة المصدرة للقرار
    val dateString: String = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()),
    val decisionNumber: String = "", // رقم القرار
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

typealias TeacherPenalty = TeacherPenaltyEntity

/**
 * رحلات وأنشطة المدرسة (School Trips)
 */
@Entity(tableName = "school_trips")
data class SchoolTripEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val schoolId: Long = 0,
    val schoolName: String,
    val destination: String, // وجهة ومكان الرحلة
    val tripDate: String, // موعد وتاريخ الرحلة
    val assemblyTime: String = "07:00 ص", // ساعة التجمع والتحرك
    val supervisors: List<String> = emptyList(), // المشرفين من قائمة معلمي المدرسة
    val studentsCount: Int = 0, // عدد الطلاب المشاركين
    val transportCompany: String = "", // شركة النقل المعتمدة
    val busNumber: String = "", // رقم الأتوبيس / السائق
    val routePlan: String = "", // خط سير الرحلة
    val securityInstructions: String = "الالتزام بالانضباط والتحرك الجماعي ومتابعة المشرفين وارتداء شارات المدرسة والتأكد من حقيبة الإسعافات",
    val approvalStatus: String = "معتمدة أمنياً",
    val timestamp: Long = System.currentTimeMillis()
)

typealias SchoolTrip = SchoolTripEntity

