package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.VicePrincipal
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduGreen
import com.example.util.AttachmentHelper

/**
 * Dialog لإضافة أو تعديل بيانات المدرسة مع دعم:
 * - كود المدرسة والرقم المسلسل
 * - الملاحظات العامة
 * - إرفاق مستندات وملفات PDF وصور خاصة بالمدرسة وتخزين مساراتها محلياً
 * - دعم ديناميكي لإضافة وكلاء حتى 4 وكلاء
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSchoolDialog(
    schoolToEdit: School? = null,
    onDismiss: () -> Unit,
    onSaveSchool: (School) -> Unit
) {
    val context = LocalContext.current
    val isEditMode = schoolToEdit != null

    var governorate by remember { mutableStateOf(schoolToEdit?.governorate ?: "المنيا") }
    var administration by remember { mutableStateOf(schoolToEdit?.administration ?: "سمالوط التعليمية") }
    var schoolName by remember { mutableStateOf(schoolToEdit?.name ?: "") }
    var schoolCode by remember { mutableStateOf(schoolToEdit?.code ?: "") }
    var serialNumber by remember { mutableStateOf(schoolToEdit?.serialNumber ?: "") }
    var selectedStage by remember { mutableStateOf(schoolToEdit?.stage ?: SchoolStage.PRIMARY) }
    var address by remember { mutableStateOf(schoolToEdit?.address ?: "") }
    var phone by remember { mutableStateOf(schoolToEdit?.phone ?: "") }
    var notes by remember { mutableStateOf(schoolToEdit?.notes ?: "") }

    // إدارة المدرسة
    var principalName by remember { mutableStateOf(schoolToEdit?.principalName ?: "") }
    var principalPhone by remember { mutableStateOf(schoolToEdit?.principalPhone ?: "") }
    var securityOfficerName by remember { mutableStateOf(schoolToEdit?.securityOfficerName ?: "") }
    var securityOfficerPhone by remember { mutableStateOf(schoolToEdit?.securityOfficerPhone ?: "") }

    // الوكلاء (ديناميكي حتى 4 وكلاء)
    val vicePrincipals = remember {
        mutableStateListOf<VicePrincipal>().apply {
            if (schoolToEdit != null && schoolToEdit.vicePrincipals.isNotEmpty()) {
                addAll(schoolToEdit.vicePrincipals.take(4))
            } else {
                add(VicePrincipal(name = "", phone = ""))
            }
        }
    }

    // التجهيزات والإحصائيات
    var classroomsCount by remember { mutableStateOf((schoolToEdit?.classroomsCount ?: 12).toString()) }
    var teachersCount by remember { mutableStateOf((schoolToEdit?.teachersCount ?: 20).toString()) }
    var workersCount by remember { mutableStateOf((schoolToEdit?.workersCount ?: 4).toString()) }
    var buildingsCount by remember { mutableStateOf((schoolToEdit?.buildingsCount ?: 1).toString()) }
    var extinguishersCount by remember { mutableStateOf((schoolToEdit?.extinguishersCount ?: 6).toString()) }
    var camerasCount by remember { mutableStateOf((schoolToEdit?.camerasCount ?: 8).toString()) }

    // مستندات وملفات PDF وصور خاصة بالمدرسة
    val attachedFiles = remember {
        mutableStateListOf<String>().apply {
            if (schoolToEdit != null) {
                addAll(schoolToEdit.attachedFiles)
            }
        }
    }

    // Document / PDF Picker Launcher
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val savedPath = AttachmentHelper.saveUriToInternalStorage(context, uri, prefix = "school_doc")
            if (savedPath != null && !attachedFiles.contains(savedPath)) {
                attachedFiles.add(savedPath)
            }
        }
    }

    // Photo Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val savedPath = AttachmentHelper.saveUriToInternalStorage(context, uri, prefix = "school_img")
            if (savedPath != null && !attachedFiles.contains(savedPath)) {
                attachedFiles.add(savedPath)
            }
        }
    }

    var isStageMenuExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.94f)
                .testTag("dialog_add_edit_school"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Dialog Title Bar
                Surface(
                    color = EduBlue,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isEditMode) Icons.Default.EditNote else Icons.Default.AddBusiness,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isEditMode) "تعديل بيانات المدرسة" else "إضافة مدرسة جديدة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                        }
                    }
                }

                // Scrollable Form Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (errorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Section 1: Basic Information & Codes
                    Text(
                        text = "١. البيانات الأساسية وكود المدرسة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = governorate,
                            onValueChange = { governorate = it },
                            label = { Text("المحافظة") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = administration,
                            onValueChange = { administration = it },
                            label = { Text("الإدارة التعليمية") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = {
                            schoolName = it
                            errorMessage = null
                        },
                        label = { Text("اسم المدرسة *") },
                        placeholder = { Text("مثال: مدرسة سمالوط الإعدادية بنين") },
                        leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_school_name"),
                        singleLine = true
                    )

                    // Code and Serial Number
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = schoolCode,
                            onValueChange = { schoolCode = it },
                            label = { Text("كود المدرسة") },
                            placeholder = { Text("مثال: SCH-104") },
                            leadingIcon = { Icon(Icons.Default.QrCode, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("input_school_code"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = serialNumber,
                            onValueChange = { serialNumber = it },
                            label = { Text("الرقم المسلسل") },
                            placeholder = { Text("مثال: 01") },
                            leadingIcon = { Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_school_serial"),
                            singleLine = true
                        )
                    }

                    // Stage Selector via Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isStageMenuExpanded,
                        onExpandedChange = { isStageMenuExpanded = !isStageMenuExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedStage.displayNameAr,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("المرحلة التعليمية *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStageMenuExpanded) },
                            leadingIcon = { Icon(Icons.Default.Category, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("dropdown_school_stage")
                        )
                        ExposedDropdownMenu(
                            expanded = isStageMenuExpanded,
                            onDismissRequest = { isStageMenuExpanded = false }
                        ) {
                            SchoolStage.values().forEach { stage ->
                                DropdownMenuItem(
                                    text = { Text(stage.displayNameAr, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        selectedStage = stage
                                        isStageMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("العنوان / الموقع") },
                        placeholder = { Text("مثال: شارع المحطة، بجوار مجلس المدينة") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Section 2: School Leadership
                    Text(
                        text = "٢. قيادات وإدارة المدرسة والأمن",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    // Principal
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = principalName,
                            onValueChange = { principalName = it },
                            label = { Text("اسم المدير") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("input_principal_name"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = principalPhone,
                            onValueChange = { principalPhone = it },
                            label = { Text("هاتف المدير") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_principal_phone"),
                            singleLine = true
                        )
                    }

                    // Vice Principals (1 to 4 dynamically)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Group, contentDescription = null, tint = EduBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "الوكلاء (${vicePrincipals.size} من 4)",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                if (vicePrincipals.size < 4) {
                                    FilledTonalButton(
                                        onClick = {
                                            vicePrincipals.add(VicePrincipal(name = "", phone = ""))
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_add_vice_principal")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إضافة وكيل آخر", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            vicePrincipals.forEachIndexed { index, vp ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = vp.name,
                                        onValueChange = { newName ->
                                            vicePrincipals[index] = vp.copy(name = newName)
                                        },
                                        label = { Text("اسم الوكيل (${index + 1})") },
                                        modifier = Modifier.weight(1.2f),
                                        singleLine = true
                                    )

                                    OutlinedTextField(
                                        value = vp.phone,
                                        onValueChange = { newPhone ->
                                            vicePrincipals[index] = vp.copy(phone = newPhone)
                                        },
                                        label = { Text("هاتف الوكيل") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        modifier = Modifier.weight(1f),
                                        singleLine = true
                                    )

                                    if (vicePrincipals.size > 1) {
                                        IconButton(
                                            onClick = { vicePrincipals.removeAt(index) },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف الوكيل",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Security Officer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = securityOfficerName,
                            onValueChange = { securityOfficerName = it },
                            label = { Text("مسؤول أمن المدرسة") },
                            leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = EduGreen) },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("input_security_officer_name"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = securityOfficerPhone,
                            onValueChange = { securityOfficerPhone = it },
                            label = { Text("هاتف مسؤول الأمن") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EduGreen) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_security_officer_phone"),
                            singleLine = true
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Section 3: Equipment & Counts
                    Text(
                        text = "٣. التجهيزات والأعداد والإحصائيات",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = classroomsCount,
                            onValueChange = { classroomsCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد الفصول") },
                            leadingIcon = { Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = teachersCount,
                            onValueChange = { teachersCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد المعلمين") },
                            leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = workersCount,
                            onValueChange = { workersCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد العمال") },
                            leadingIcon = { Icon(Icons.Default.Engineering, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = buildingsCount,
                            onValueChange = { buildingsCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد المباني") },
                            leadingIcon = { Icon(Icons.Default.Apartment, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = extinguishersCount,
                            onValueChange = { extinguishersCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد الطفايات") },
                            leadingIcon = { Icon(Icons.Default.FireExtinguisher, contentDescription = null, tint = Color(0xFFD32F2F)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = camerasCount,
                            onValueChange = { camerasCount = it.filter { ch -> ch.isDigit() } },
                            label = { Text("عدد الكاميرات") },
                            leadingIcon = { Icon(Icons.Default.Videocam, contentDescription = null, tint = EduGreen) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Section 4: Notes and Attached Files
                    Text(
                        text = "٤. الملاحظات العامة وإرفاق المستندات والصور",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("الملاحظات العامة للمدرسة") },
                        placeholder = { Text("اكتب أي تفاصيل إضافية أو تعليمات أمنية تخص المدرسة...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_school_notes"),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Attached Files Section
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المستندات والملفات المرفقة (${attachedFiles.size})",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = {
                                            documentPickerLauncher.launch(arrayOf("application/pdf", "*/*"))
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_attach_school_pdf")
                                    ) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("PDF / مستند", style = MaterialTheme.typography.labelSmall)
                                    }

                                    FilledTonalButton(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_attach_school_photo")
                                    ) {
                                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("صورة", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }

                            if (attachedFiles.isEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "لا توجد مستندات أو صور مرفقة حالياً",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Spacer(modifier = Modifier.height(10.dp))
                                attachedFiles.forEachIndexed { index, path ->
                                    val isPdf = AttachmentHelper.isPdf(path)
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surface
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { AttachmentHelper.openAttachment(context, path) }
                                            ) {
                                                Icon(
                                                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                                    contentDescription = null,
                                                    tint = if (isPdf) Color(0xFFD32F2F) else EduBlue,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = AttachmentHelper.getDisplayName(path),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            IconButton(
                                                onClick = { attachedFiles.removeAt(index) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "حذف المرفق",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Action Buttons Footer
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إلغاء")
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                if (schoolName.trim().isBlank()) {
                                    errorMessage = "يرجى كتابة اسم المدرسة"
                                    return@Button
                                }

                                val validVicePrincipals = vicePrincipals
                                    .filter { it.name.isNotBlank() || it.phone.isNotBlank() }
                                    .take(4)

                                val newSchool = School(
                                    id = schoolToEdit?.id ?: 0L,
                                    governorate = governorate.ifBlank { "المنيا" },
                                    administration = administration.ifBlank { "سمالوط التعليمية" },
                                    name = schoolName.trim(),
                                    code = schoolCode.trim(),
                                    serialNumber = serialNumber.trim(),
                                    stage = selectedStage,
                                    principalName = principalName.trim(),
                                    principalPhone = principalPhone.trim(),
                                    vicePrincipals = validVicePrincipals,
                                    securityOfficerName = securityOfficerName.trim(),
                                    securityOfficerPhone = securityOfficerPhone.trim(),
                                    classroomsCount = classroomsCount.toIntOrNull() ?: 0,
                                    teachersCount = teachersCount.toIntOrNull() ?: 0,
                                    workersCount = workersCount.toIntOrNull() ?: 0,
                                    buildingsCount = buildingsCount.toIntOrNull() ?: 0,
                                    extinguishersCount = extinguishersCount.toIntOrNull() ?: 0,
                                    camerasCount = camerasCount.toIntOrNull() ?: 0,
                                    address = address.trim(),
                                    phone = principalPhone.trim(),
                                    notes = notes.trim(),
                                    attachedFiles = attachedFiles.toList()
                                )

                                onSaveSchool(newSchool)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_save_school")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEditMode) "حفظ التعديلات" else "إضافة المدرسة",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
