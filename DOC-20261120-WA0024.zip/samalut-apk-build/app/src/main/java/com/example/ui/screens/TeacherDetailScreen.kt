package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DailyLogEntry
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.model.TeacherLeaveEntity
import com.example.data.model.TeacherPenaltyEntity
import com.example.ui.components.AttachmentViewerDialog
import com.example.ui.components.CompactTopBar
import com.example.ui.components.PersonAvatar
import com.example.util.TeacherPhotoHelper
import com.example.ui.theme.*
import com.example.util.AttachmentHelper
import com.example.util.WhatsAppHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherDetailScreen(
    teacher: Teacher?,
    incidents: List<SecurityIncident>,
    dailyLogs: List<DailyLogEntry>,
    leaves: List<TeacherLeaveEntity> = emptyList(),
    penalties: List<TeacherPenaltyEntity> = emptyList(),
    onSchoolClick: (String) -> Unit,
    onIncidentClick: (Long) -> Unit,
    onAddDailyLog: (DailyLogEntry) -> Unit,
    onUpdateDailyLog: (DailyLogEntry) -> Unit = {},
    onDeleteDailyLog: (DailyLogEntry) -> Unit = {},
    onAddLeave: (TeacherLeaveEntity) -> Unit = {},
    onDeleteLeave: (TeacherLeaveEntity) -> Unit = {},
    onAddPenalty: (TeacherPenaltyEntity) -> Unit = {},
    onDeletePenalty: (TeacherPenaltyEntity) -> Unit = {},
    onUpdateTeacher: ((Teacher) -> Unit)? = null,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var showAddLogDialog by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var editingLog by remember { mutableStateOf<DailyLogEntry?>(null) }
    var logToDelete by remember { mutableStateOf<DailyLogEntry?>(null) }
    var photoVersion by remember { mutableStateOf(0) }

    // اختيار صورة المعلم
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null && teacher != null) {
            if (TeacherPhotoHelper.savePhoto(context, uri, teacher.id)) {
                photoVersion++
                Toast.makeText(context, "تم حفظ صورة المعلم", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "تعذر حفظ الصورة، جرّب صورة أخرى", Toast.LENGTH_SHORT).show()
            }
        }
    }
    var showAddLeaveDialog by remember { mutableStateOf(false) }
    var showAddPenaltyDialog by remember { mutableStateOf(false) }
    var viewingAttachment by remember { mutableStateOf<String?>(null) }

    // Document and Photo Pickers for Teacher
    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (teacher != null && onUpdateTeacher != null) {
            val newPaths = uris.mapNotNull { AttachmentHelper.saveUriToInternalStorage(context, it, "teacher_doc") }
            if (newPaths.isNotEmpty()) {
                onUpdateTeacher(teacher.copy(attachedFiles = teacher.attachedFiles + newPaths))
            }
        }
    }

    val imgPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (teacher != null && onUpdateTeacher != null) {
            val newPaths = uris.mapNotNull { AttachmentHelper.saveUriToInternalStorage(context, it, "teacher_img") }
            if (newPaths.isNotEmpty()) {
                onUpdateTeacher(teacher.copy(attachedFiles = teacher.attachedFiles + newPaths))
            }
        }
    }

    if (teacher == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    // Attachment Viewer
    if (viewingAttachment != null) {
        AttachmentViewerDialog(
            filePath = viewingAttachment!!,
            onDismiss = { viewingAttachment = null },
            onDelete = {
                val target = viewingAttachment
                if (target != null && onUpdateTeacher != null) {
                    onUpdateTeacher(teacher.copy(attachedFiles = teacher.attachedFiles.filter { it != target }))
                }
                viewingAttachment = null
            }
        )
    }

    val linkedIncidents = incidents.filter {
        it.partiesInvolved.contains(teacher.name) ||
                it.description.contains(teacher.name) ||
                it.schoolName == teacher.schoolName
    }
    val teacherLogs = dailyLogs.filter { it.teacherName == teacher.name }
    val teacherLeaves = leaves.filter { it.teacherId == teacher.id || it.teacherName == teacher.name }
    val teacherPenalties = penalties.filter { it.teacherId == teacher.id || it.teacherName == teacher.name }

    // Check Active Leave Status
    val activeLeave = teacherLeaves.firstOrNull { it.isCurrentlyActive }

    Scaffold(
        topBar = {
            CompactTopBar(
                title = "ملف المعلم / الموظف",
                onBackClick = onBackClick
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card with Status Indicator
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val photoPath = remember(teacher.id, photoVersion) {
                            TeacherPhotoHelper.getPhotoPath(context, teacher.id)
                        }
                        Box(
                            modifier = Modifier
                                .clickable {
                                    photoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("teacher_photo")
                        ) {
                            PersonAvatar(photoPath = photoPath, size = 84.dp)
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(26.dp)
                                    .background(EduBlue, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = "تغيير الصورة",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        if (photoPath.isNotBlank()) {
                            TextButton(
                                onClick = {
                                    TeacherPhotoHelper.deletePhoto(context, teacher.id)
                                    photoVersion++
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text("حذف الصورة", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        } else {
                            Text(
                                text = "اضغط على الأيقونة لإضافة صورة",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = teacher.name,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "${teacher.jobTitle} • ${teacher.subject}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Work / Leave Status Indicator Badge (على رأس العمل / في إجازة)
                        if (activeLeave != null) {
                            Surface(
                                color = Color(0xFFFFF3E0),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB74D))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.BeachAccess,
                                        contentDescription = null,
                                        tint = Color(0xFFE65100),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "في إجازة (${activeLeave.leaveType}) حتى ${activeLeave.endDate}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color(0xFFE65100)
                                    )
                                }
                            }
                        } else {
                            Surface(
                                color = Color(0xFFE8F5E9),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF81C784))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "على رأس العمل 🟢",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color(0xFF2E7D32)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Communication Buttons: WhatsApp + Call
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    WhatsAppHelper.openWhatsApp(
                                        context,
                                        teacher.phone,
                                        "السلام عليكم أ/ ${teacher.name}، معك إدارة أمن الإدارة التعليمية بسمالوط (مسؤول الأمن: مستر مصطفى فرغلي) بخصوص متابعة العمل المدرسي."
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("teacher_detail_whatsapp_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("واتساب 🟢", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { WhatsAppHelper.makePhoneCall(context, teacher.phone) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("teacher_detail_call_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, tint = EduBlue)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("اتصال 📞", fontWeight = FontWeight.Bold, color = EduBlue)
                            }
                        }
                    }
                }
            }

            // Information Grid
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "البيانات الوظيفية والشخصية",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = EduBlue,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        if (teacher.teacherCode.isNotBlank()) {
                            InfoRow(icon = Icons.Default.QrCode, label = "كود المعلم", value = teacher.teacherCode)
                        }
                        InfoRow(icon = Icons.Default.School, label = "المدرسة", value = teacher.schoolName, isClickable = true, onClick = { onSchoolClick(teacher.schoolName) })
                        InfoRow(icon = Icons.Default.Category, label = "المرحلة", value = teacher.stage.displayNameAr)
                        InfoRow(icon = Icons.Default.Work, label = "الوظيفة الحالية", value = teacher.jobTitle)
                        if (teacher.assignedDuty.isNotBlank()) {
                            InfoRow(icon = Icons.Default.AssignmentInd, label = "التكليف المدرسي", value = teacher.assignedDuty)
                        }
                        InfoRow(icon = Icons.Default.MenuBook, label = "التخصص / المادة", value = teacher.subject)
                        InfoRow(icon = Icons.Default.Phone, label = "رقم الهاتف", value = teacher.phone.ifBlank { "غير مسجل" })
                        InfoRow(icon = Icons.Default.Badge, label = "الرقم القومي", value = teacher.nationalId.ifBlank { "غير مسجل" })
                        InfoRow(icon = Icons.Default.CalendarToday, label = "تاريخ التعيين", value = teacher.hireDate.ifBlank { "غير مسجل" })
                        if (teacher.address.isNotBlank()) {
                            InfoRow(icon = Icons.Default.Home, label = "محل الإقامة", value = teacher.address)
                        }
                        if (teacher.notes.isNotBlank()) {
                            InfoRow(icon = Icons.Default.Notes, label = "الملاحظات", value = teacher.notes)
                        }
                    }
                }
            }

            // Attached Files Section (PDF / Photos)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المستندات والملفات المرفقة (${teacher.attachedFiles.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = EduBlue
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(
                                    onClick = { docPicker.launch(arrayOf("application/pdf", "*/*")) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("PDF / قرار", style = MaterialTheme.typography.labelSmall)
                                }

                                FilledTonalButton(
                                    onClick = {
                                        imgPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("صورة", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        if (teacher.attachedFiles.isEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا توجد مستندات أو قرارات مرفقة للمعلم حتى الآن",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Spacer(modifier = Modifier.height(10.dp))
                            teacher.attachedFiles.forEach { filePath ->
                                val isPdf = AttachmentHelper.isPdf(filePath)
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .clickable { viewingAttachment = filePath },
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                                contentDescription = null,
                                                tint = if (isPdf) Color(0xFFD32F2F) else EduBlue,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = AttachmentHelper.getDisplayName(filePath),
                                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                                    maxLines = 1
                                                )
                                                Text(
                                                    text = AttachmentHelper.getFileSizeFormatted(filePath),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            IconButton(
                                                onClick = { AttachmentHelper.shareToWhatsApp(context, filePath) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Chat, contentDescription = "مشاركة واتساب", tint = Color(0xFF2E7D32), modifier = Modifier.size(17.dp))
                                            }
                                            IconButton(
                                                onClick = { AttachmentHelper.printAttachment(context, filePath) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Print, contentDescription = "طباعة المستند", tint = EduBlue, modifier = Modifier.size(17.dp))
                                            }
                                            IconButton(
                                                onClick = { viewingAttachment = filePath },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Visibility, contentDescription = "معاينة", tint = EduBlueDark, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 1: Teacher Leaves Record (سجل إجازات المعلم)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BeachAccess, contentDescription = null, tint = Color(0xFFE65100))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "سجل الإجازات الرسمية (${teacherLeaves.size})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFE65100)
                                )
                            }

                            FilledTonalButton(
                                onClick = { showAddLeaveDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_add_teacher_leave")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تسجيل إجازة", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        if (teacherLeaves.isEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا توجد إجازات مسجلة للمعلم في السجل",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Spacer(modifier = Modifier.height(10.dp))
                            teacherLeaves.forEach { leave ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (leave.isCurrentlyActive) Color(0xFFFFF8E1) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = if (leave.isCurrentlyActive) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFCA28)) else null
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = Color(0xFFE65100).copy(alpha = 0.15f),
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = leave.leaveType,
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = Color(0xFFE65100),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${leave.daysCount} يوم",
                                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                if (leave.isCurrentlyActive) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = "• سارية حالياً",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = Color(0xFFC62828)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "الفترة: من ${leave.startDate} إلى ${leave.endDate}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                            Text(
                                                text = "الجهة / المكان: ${leave.destination}" + if (leave.notes.isNotBlank()) " • ${leave.notes}" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteLeave(leave) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف الإجازة", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: Teacher Penalties Record (سجل الجزاءات والخصومات)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Gavel, contentDescription = null, tint = Color(0xFFC62828))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "سجل الجزاءات والخصومات (${teacherPenalties.size})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFC62828)
                                )
                            }

                            FilledTonalButton(
                                onClick = { showAddPenaltyDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_add_teacher_penalty")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تسجيل جزاء", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        if (teacherPenalties.isEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سجل المعلم نظيف تماماً - لا توجد أي جزاءات أو خصومات مسجلة 🟢",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Spacer(modifier = Modifier.height(10.dp))
                            teacherPenalties.forEach { penalty ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFFFEBEE).copy(alpha = 0.5f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFCDD2))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = Color(0xFFC62828).copy(alpha = 0.15f),
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = penalty.penaltyType,
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = Color(0xFFC62828),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                if (penalty.daysDeducted > 0) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = "خصم ${penalty.daysDeducted} أيام",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = Color(0xFFC62828)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "تاريخ: ${penalty.dateString}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "السبب: ${penalty.reason}",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                                            )
                                            Text(
                                                text = "الجهة المصدرة: ${penalty.issuingAuthority}" +
                                                        if (penalty.decisionNumber.isNotBlank()) " (قرار رقم ${penalty.decisionNumber})" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeletePenalty(penalty) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف الجزاء", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Linked Incidents
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "الأحداث والوقائع المرتبطة (${linkedIncidents.size})",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    if (linkedIncidents.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "لا توجد وقائع مسجلة مرتبطة بالمعلم - السجل نظيف تماماً",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        linkedIncidents.forEach { incident ->
                            RecentIncidentItem(incident = incident, onClick = { onIncidentClick(incident.id) })
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }

            // Daily Logs
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سجل الملاحظات اليومية (${teacherLogs.size})",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        TextButton(onClick = {
                            noteText = ""
                            showAddLogDialog = true
                        }) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة ملاحظة")
                        }
                    }

                    if (teacherLogs.isEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "لا توجد ملاحظات مرور أمني مسجلة للمعلم",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        teacherLogs.forEach { log ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = log.dateString, style = MaterialTheme.typography.labelSmall, color = EduBlue)
                                            Text(text = log.supervisor, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Row {
                                            IconButton(
                                                onClick = {
                                                    noteText = log.note
                                                    editingLog = log
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("btn_edit_note_${log.id}")
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "تعديل الملاحظة", tint = EduBlue, modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(
                                                onClick = { logToDelete = log },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .testTag("btn_delete_note_${log.id}")
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "حذف الملاحظة", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = log.note, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Log Dialog
    if (showAddLogDialog || editingLog != null) {
        val isEditing = editingLog != null
        AlertDialog(
            onDismissRequest = {
                showAddLogDialog = false
                editingLog = null
                noteText = ""
            },
            title = { Text(if (isEditing) "تعديل الملاحظة" else "إضافة ملاحظة للمعلم") },
            text = {
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("الملاحظة الأمنية أو الإدارية") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteText.isNotBlank()) {
                            val current = editingLog
                            if (current != null) {
                                onUpdateDailyLog(current.copy(note = noteText.trim()))
                            } else {
                                onAddDailyLog(
                                    DailyLogEntry(
                                        schoolName = teacher.schoolName,
                                        teacherName = teacher.name,
                                        note = noteText.trim(),
                                        supervisor = "مستر مصطفى فرغلي"
                                    )
                                )
                            }
                            noteText = ""
                            editingLog = null
                            showAddLogDialog = false
                        }
                    }
                ) {
                    Text(if (isEditing) "حفظ التعديل" else "حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddLogDialog = false
                    editingLog = null
                    noteText = ""
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Delete Log Confirmation
    if (logToDelete != null) {
        AlertDialog(
            onDismissRequest = { logToDelete = null },
            title = { Text("حذف الملاحظة") },
            text = { Text("هل تريد حذف هذه الملاحظة نهائياً؟") },
            confirmButton = {
                Button(
                    onClick = {
                        logToDelete?.let { onDeleteDailyLog(it) }
                        logToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { logToDelete = null }) { Text("إلغاء") }
            }
        )
    }

    // Dialog: Add Teacher Leave (تسجيل إجازة جديدة)
    if (showAddLeaveDialog) {
        AddTeacherLeaveDialog(
            teacher = teacher,
            onDismiss = { showAddLeaveDialog = false },
            onSave = { newLeave ->
                onAddLeave(newLeave)
                showAddLeaveDialog = false
            }
        )
    }

    // Dialog: Add Teacher Penalty (تسجيل جزاء جديد)
    if (showAddPenaltyDialog) {
        AddTeacherPenaltyDialog(
            teacher = teacher,
            onDismiss = { showAddPenaltyDialog = false },
            onSave = { newPenalty ->
                onAddPenalty(newPenalty)
                showAddPenaltyDialog = false
            }
        )
    }
}

/**
 * Dialog تسجيل إجازة المعلم مع الحساب التلقائي للأيام
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTeacherLeaveDialog(
    teacher: Teacher,
    onDismiss: () -> Unit,
    onSave: (TeacherLeaveEntity) -> Unit
) {
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    val today = sdf.format(Date())

    val leaveTypes = listOf("اعتيادي", "عارضة", "مرضي", "وضع", "رعاية طفل", "خاصة بدون مرتب", "أخرى")
    var selectedLeaveType by remember { mutableStateOf(leaveTypes.first()) }
    var isTypeMenuExpanded by remember { mutableStateOf(false) }

    var startDate by remember { mutableStateOf(today) }
    var endDate by remember { mutableStateOf(today) }
    var destination by remember { mutableStateOf("داخل القطر") }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Automatic Days Count Calculation
    val calculatedDays = remember(startDate, endDate) {
        try {
            val d1 = sdf.parse(startDate.replace("-", "/"))
            val d2 = sdf.parse(endDate.replace("-", "/"))
            if (d1 != null && d2 != null) {
                val diff = d2.time - d1.time
                val days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) + 1
                days.toInt().coerceAtLeast(1)
            } else 1
        } catch (e: Exception) {
            1
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تسجيل إجازة رسمية: ${teacher.name}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                }

                // Leave Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = isTypeMenuExpanded,
                    onExpandedChange = { isTypeMenuExpanded = !isTypeMenuExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedLeaveType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("نوع الإجازة *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isTypeMenuExpanded,
                        onDismissRequest = { isTypeMenuExpanded = false }
                    ) {
                        leaveTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = {
                                    selectedLeaveType = type
                                    isTypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Dates
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("من تاريخ") },
                        placeholder = { Text("YYYY/MM/DD") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("إلى تاريخ") },
                        placeholder = { Text("YYYY/MM/DD") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Days Count Info Pill
                Surface(
                    color = EduBlue.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "المدة المحسوبة تلقائياً: $calculatedDays يوم",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text("مكان وقضاء الإجازة (داخل / خارج القطر)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (startDate.isBlank() || endDate.isBlank()) {
                        errorMessage = "يرجى تحديد تاريخ البداية والنهاية"
                        return@Button
                    }
                    val leave = TeacherLeaveEntity(
                        teacherId = teacher.id,
                        teacherName = teacher.name,
                        schoolName = teacher.schoolName,
                        leaveType = selectedLeaveType,
                        startDate = startDate.trim(),
                        endDate = endDate.trim(),
                        daysCount = calculatedDays,
                        destination = destination.trim().ifBlank { "داخل القطر" },
                        notes = notes.trim()
                    )
                    onSave(leave)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EduGreen)
            ) {
                Text("حفظ الإجازة")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

/**
 * Dialog تسجيل جزاء المعلم
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTeacherPenaltyDialog(
    teacher: Teacher,
    onDismiss: () -> Unit,
    onSave: (TeacherPenaltyEntity) -> Unit
) {
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    val today = sdf.format(Date())

    val penaltyTypes = listOf("إنذار", "لفت نظر", "خصم من الراتب", "تأخير", "إيقاف عن العمل")
    var selectedPenaltyType by remember { mutableStateOf(penaltyTypes.first()) }
    var isTypeMenuExpanded by remember { mutableStateOf(false) }

    var daysDeducted by remember { mutableStateOf("0") }
    var reason by remember { mutableStateOf("") }
    var issuingAuthority by remember { mutableStateOf("الشؤون القانونية بالإدارة") }
    var decisionNumber by remember { mutableStateOf("") }
    var penaltyDate by remember { mutableStateOf(today) }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تسجيل جزاء أو خصم: ${teacher.name}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                }

                // Penalty Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = isTypeMenuExpanded,
                    onExpandedChange = { isTypeMenuExpanded = !isTypeMenuExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedPenaltyType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("نوع الجزاء *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isTypeMenuExpanded,
                        onDismissRequest = { isTypeMenuExpanded = false }
                    ) {
                        penaltyTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = {
                                    selectedPenaltyType = type
                                    isTypeMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                if (selectedPenaltyType.contains("خصم") || selectedPenaltyType.contains("إيقاف")) {
                    OutlinedTextField(
                        value = daysDeducted,
                        onValueChange = { daysDeducted = it.filter { ch -> ch.isDigit() } },
                        label = { Text("عدد أيام الخصم / الإيقاف") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("سبب وتفاصيل الجزاء *") },
                    placeholder = { Text("مثال: الغياب بدون إذن مسبق / التقصير في الإشراف...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = issuingAuthority,
                        onValueChange = { issuingAuthority = it },
                        label = { Text("الجهة المصدرة") },
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = decisionNumber,
                        onValueChange = { decisionNumber = it },
                        label = { Text("رقم القرار") },
                        modifier = Modifier.weight(0.8f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = penaltyDate,
                    onValueChange = { penaltyDate = it },
                    label = { Text("تاريخ الجزاء") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reason.trim().isBlank()) {
                        errorMessage = "يرجى كتابة سبب وتفاصيل الجزاء"
                        return@Button
                    }
                    val penalty = TeacherPenaltyEntity(
                        teacherId = teacher.id,
                        teacherName = teacher.name,
                        schoolName = teacher.schoolName,
                        penaltyType = selectedPenaltyType,
                        daysDeducted = daysDeducted.toIntOrNull() ?: 0,
                        reason = reason.trim(),
                        issuingAuthority = issuingAuthority.trim().ifBlank { "الشؤون القانونية بالإدارة" },
                        decisionNumber = decisionNumber.trim(),
                        dateString = penaltyDate.trim(),
                        notes = notes.trim()
                    )
                    onSave(penalty)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("حفظ الجزاء")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun InfoRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    isClickable: Boolean = false,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isClickable) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = EduBlue,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isClickable) FontWeight.Bold else FontWeight.Normal,
                color = if (isClickable) EduBlue else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}

