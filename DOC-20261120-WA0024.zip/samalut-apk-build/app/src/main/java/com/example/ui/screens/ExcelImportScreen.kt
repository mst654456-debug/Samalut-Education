package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ImportSummary
import com.example.ui.theme.*
import com.example.util.ExcelHelper

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExcelImportScreen(
    importMessage: String?,
    isImporting: Boolean = false,
    importSummary: ImportSummary? = null,
    onImportSchools: (String) -> Unit = {},
    onImportSchoolsRows: (List<List<String>>) -> Unit = {},
    onImportTeachers: (String) -> Unit = {},
    onImportTeachersRows: (List<List<String>>) -> Unit = {},
    onDismissSummary: () -> Unit = {},
    onNavigateToSchools: () -> Unit = {},
    onNavigateToTeachers: () -> Unit = {},
    onClearMessage: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedImportType by remember { mutableStateOf(0) } // 0: Teachers, 1: Schools
    var inputText by remember { mutableStateOf(ExcelHelper.getSampleTeachersCsv()) }
    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var parsedRows by remember { mutableStateOf<List<List<String>>>(emptyList()) }

    // File picker launcher for XLSX, XLS, and CSV
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, rows) = ExcelHelper.readRowsFromUri(context, uri)
            selectedFileName = name
            if (rows.isNotEmpty()) {
                parsedRows = rows
                inputText = rows.joinToString("\n") { row ->
                    row.joinToString(",") { cell ->
                        if (cell.contains(",") || cell.contains("\n") || cell.contains("\"")) {
                            "\"${cell.replace("\"", "\"\"")}\""
                        } else {
                            cell
                        }
                    }
                }
            } else {
                val fallbackText = ExcelHelper.readContentFromUri(context, uri)
                if (fallbackText != null) {
                    inputText = fallbackText
                    parsedRows = ExcelHelper.parseTextToRows(fallbackText)
                }
            }
        }
    }

    LaunchedEffect(selectedImportType) {
        if (selectedFileName == null) {
            parsedRows = emptyList()
            inputText = if (selectedImportType == 0) {
                ExcelHelper.getSampleTeachersCsv()
            } else {
                ExcelHelper.getSampleSchoolsCsv()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "استيراد بيانات Excel و CSV",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status Banner if any
            if (importMessage != null && importSummary == null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = EduGreen.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EduGreen)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = importMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = EduGreen,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onClearMessage) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = EduGreen)
                        }
                    }
                }
            }

            // Progress Bar during import execution
            if (isImporting) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.5.dp,
                                color = EduBlue
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "جاري قراءة الملف وتدقيق السجلات وتفادي التكرار...",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = EduBlue
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .testTag("import_linear_progress"),
                            color = EduBlue,
                            trackColor = EduBlue.copy(alpha = 0.2f)
                        )
                    }
                }
            }

            // Tab Selector: Teachers vs Schools
            TabRow(
                selectedTabIndex = selectedImportType,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EduBlue,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .testTag("import_tab_row")
            ) {
                Tab(
                    selected = selectedImportType == 0,
                    onClick = {
                        selectedImportType = 0
                        selectedFileName = null
                        parsedRows = emptyList()
                    },
                    text = {
                        Text(
                            text = "شيت المعلمين (10 أعمدة)",
                            fontWeight = if (selectedImportType == 0) FontWeight.Bold else FontWeight.Normal,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                )
                Tab(
                    selected = selectedImportType == 1,
                    onClick = {
                        selectedImportType = 1
                        selectedFileName = null
                        parsedRows = emptyList()
                    },
                    text = {
                        Text(
                            text = "شيت المدارس (16 عموداً)",
                            fontWeight = if (selectedImportType == 1) FontWeight.Bold else FontWeight.Normal,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                )
            }

            // Column Mapping & Guide Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = null,
                            tint = EduBlue
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedImportType == 0) "ترتيب أعمدة ملف المعلمين المعتمد:" else "ترتيب أعمدة ملف المدارس المعتمد:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val columnsList = if (selectedImportType == 0) {
                        listOf(
                            "1. م",
                            "2. الاسم",
                            "3. كود المعلم",
                            "4. الرقم القومي",
                            "5. اسم المدرسة",
                            "6. الوظيفة",
                            "7. العمل المكلف به",
                            "8. رقم التليفون",
                            "9. العنوان",
                            "10. الملاحظات"
                        )
                    } else {
                        listOf(
                            "1. الرقم المسلسل",
                            "2. اسم المدرسة",
                            "3. المرحلة",
                            "4. كود المدرسة",
                            "5. اسم المدير",
                            "6. هاتف المدير",
                            "7. اسم الوكيل",
                            "8. هاتف الوكيل",
                            "9. مسؤول الأمن",
                            "10. هاتف مسؤول الأمن",
                            "11. عدد الفصول",
                            "12. عدد العاملين",
                            "13. عدد الكاميرات",
                            "14. عدد المباني",
                            "15. عدد العمال",
                            "16. الملاحظات"
                        )
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        columnsList.forEach { colName ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (colName.contains("كود") || colName.contains("القومي")) EduBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background,
                                border = if (colName.contains("كود") || colName.contains("القومي")) {
                                    androidx.compose.foundation.BorderStroke(1.dp, EduBlue.copy(alpha = 0.4f))
                                } else null
                            ) {
                                Text(
                                    text = colName,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (colName.contains("كود") || colName.contains("القومي")) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (colName.contains("كود") || colName.contains("القومي")) EduBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (selectedImportType == 0) {
                            "💡 تفادي التكرار: يقوم المعالج بالتحقق من كود المعلم والرقم القومي، وفي حال وجود السجل مسبقاً يتم تحديثه تلقائياً وربطه بمدرسته."
                        } else {
                            "💡 تفادي التكرار: يتم فحص كود المدرسة واسمها بدقة، وفي حال وجودها مسبقاً يتم تحديث بياناتها دون تكرار السجل."
                        },
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                        color = Color(0xFF0D47A1)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Buttons Row: Pick File & Load Sample
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                filePickerLauncher.launch(
                                    arrayOf(
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                                        "application/vnd.ms-excel", // .xls
                                        "text/csv",
                                        "text/comma-separated-values",
                                        "text/plain",
                                        "*/*"
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isImporting,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(48.dp)
                                .testTag("pick_excel_file_button")
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار ملف (XLSX / CSV)", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                selectedFileName = null
                                parsedRows = emptyList()
                                inputText = if (selectedImportType == 0) {
                                    ExcelHelper.getSampleTeachersCsv()
                                } else {
                                    ExcelHelper.getSampleSchoolsCsv()
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isImporting,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = EduGoldDark)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("النموذج النموذجي", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (selectedFileName != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = EduGreen.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AttachFile, contentDescription = null, tint = EduGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "الملف المختار: $selectedFileName ${if (parsedRows.isNotEmpty()) "(${parsedRows.size} صف)" else ""}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = EduGreen,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = {
                                        selectedFileName = null
                                        parsedRows = emptyList()
                                        inputText = if (selectedImportType == 0) ExcelHelper.getSampleTeachersCsv() else ExcelHelper.getSampleSchoolsCsv()
                                    }
                                ) {
                                    Text("مسح", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            // Text Preview / Edit Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "معاينة وتحرير محتوى الشيت:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EduBlue.copy(alpha = 0.1f)
                        ) {
                            Text(
                                text = if (selectedFileName != null) "مستورد من ملف" else "نموذج قابل للتعديل",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = EduBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = {
                            inputText = it
                            parsedRows = emptyList() // User edited manually
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .testTag("excel_preview_text"),
                        shape = RoundedCornerShape(10.dp),
                        textStyle = MaterialTheme.typography.bodySmall,
                        placeholder = { Text("الصق بيانات Excel هنا أو اختر ملفاً...") }
                    )
                }
            }

            // Execute Import Button
            Button(
                onClick = {
                    if (selectedImportType == 0) {
                        if (parsedRows.isNotEmpty()) {
                            onImportTeachersRows(parsedRows)
                        } else {
                            onImportTeachers(inputText)
                        }
                    } else {
                        if (parsedRows.isNotEmpty()) {
                            onImportSchoolsRows(parsedRows)
                        } else {
                            onImportSchools(inputText)
                        }
                    }
                },
                enabled = !isImporting && inputText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("execute_import_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (selectedImportType == 0) "بدء استيراد وتحديث سجل المعلمين 🚀" else "بدء استيراد وتحديث شيت المدارس 🚀",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Quick Post-Import Summary Report Dialog (تقرير سريع بعد الاستيراد)
    if (importSummary != null) {
        AlertDialog(
            onDismissRequest = onDismissSummary,
            modifier = Modifier.testTag("import_summary_dialog"),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(EduGreen.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EduGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تقرير نتيجة الاستيراد وتحديث البيانات",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = importSummary.message,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Stats Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Added
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = EduGreen.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EduGreen.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${importSummary.addedCount}",
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EduGreen
                                )
                                Text(
                                    text = "جديد مضاف",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EduGreen
                                )
                            }
                        }

                        // Updated
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = EduBlue.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EduBlue.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${importSummary.updatedCount}",
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EduBlue
                                )
                                Text(
                                    text = "تم تحديثه (تكرار)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EduBlue
                                )
                            }
                        }

                        // Total
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${importSummary.totalProcessed}",
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "إجمالي الصفوف",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Notice if errors exist
                    if (importSummary.errorsCount > 0) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "تم تجاوز ${importSummary.errorsCount} صف به بيانات غير مكتملة:",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                importSummary.errors.take(3).forEach { err ->
                                    Text(
                                        text = "• $err",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDismissSummary()
                        if (selectedImportType == 0) {
                            onNavigateToTeachers()
                        } else {
                            onNavigateToSchools()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (selectedImportType == 0) "عرض قائمة المعلمين" else "عرض قائمة المدارس")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissSummary) {
                    Text("إغلاق")
                }
            }
        )
    }
}
