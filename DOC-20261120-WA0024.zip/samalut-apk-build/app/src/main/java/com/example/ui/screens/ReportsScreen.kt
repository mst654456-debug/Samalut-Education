package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IncidentStatus
import com.example.data.model.SecurityIncident
import com.example.data.preferences.AdminConfig
import com.example.ui.theme.*
import com.example.util.ReportExporter
import com.example.util.WhatsAppHelper
import java.util.Calendar
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    incidents: List<SecurityIncident>,
    adminConfig: AdminConfig = AdminConfig(),
    supervisorName: String = adminConfig.securityOfficerName,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedDate by remember { mutableStateOf(Date()) }
    var selectedPeriod by remember { mutableStateOf(ReportExporter.ReportPeriod.DAILY) }

    // الأحداث المفلترة لليوم المختار
    val dayIncidents = remember(selectedDate, incidents) {
        ReportExporter.filterIncidentsByDate(incidents, selectedDate)
    }

    val dayDateText = remember(selectedDate) {
        ReportExporter.formatOfficialDayDate(selectedDate)
    }

    val reportText = remember(selectedPeriod, selectedDate, incidents, adminConfig) {
        ReportExporter.generateReportText(selectedPeriod, incidents, adminConfig, selectedDate)
    }

    // عرض منتقي التاريخ
    val showDatePicker = {
        val cal = Calendar.getInstance().apply { time = selectedDate }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val newCal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                }
                selectedDate = newCal.time
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "التقارير الأمنية وتصدير المستندات",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // كارت اختيار التاريخ وتحديد اليوم للتقرير
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "تاريخ التقرير اليومي المحدد:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dayDateText,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EduBlue
                            )
                        }

                        Button(
                            onClick = showDatePicker,
                            colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("pick_report_date_button")
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تغيير التاريخ", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // أزرار سريعة لاختيار التاريخ (اليوم / أمس)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { selectedDate = Date() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("اليوم", style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = {
                                val cal = Calendar.getInstance().apply {
                                    time = Date()
                                    add(Calendar.DAY_OF_YEAR, -1)
                                }
                                selectedDate = cal.time
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("أمس", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // بطاقة المعاينة الرسمية للتقرير (خلو أحداث أم وجود أحداث)
            if (dayIncidents.isEmpty()) {
                // شرط "تقرير خلو الأحداث" (إفادة خلو أحداث)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("no_incidents_certificate_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FBFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, EduBlue.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                            .padding(18.dp)
                    ) {
                        // 1. الترويسة العلوية
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = adminConfig.directorateName,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = adminConfig.administrationName,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = "مكتب الأمن",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Surface(
                                color = EduBlue.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "تقرير الأحداث اليومية للمدارس",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EduBlue
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(thickness = 1.5.dp, color = EduBlue)
                        Spacer(modifier = Modifier.height(24.dp))

                        // 2. منتصف الصفحة:
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFEFF6FF), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(12.dp))
                                .padding(vertical = 24.dp, horizontal = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = EduGreen,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // كتابة اليوم والتاريخ بالتنسيق: [اليوم] [DD / MM / YYYY] بخط واضح وكبير
                            Text(
                                text = dayDateText,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                ),
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // نص واضح ومميز أسفل التاريخ مباشرة: "لا توجد أحداث بالإدارة لهذا اليوم"
                            Text(
                                text = "لا توجد أحداث بالإدارة لهذا اليوم",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 22.sp
                                ),
                                color = Color(0xFF1D4ED8),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "إفادة رسمية باستقرار الحالة الأمنية العامة بمدارس الإدارة",
                                style = MaterialTheme.typography.bodySmall,
                                color = EduGreen,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                        HorizontalDivider(thickness = 1.dp, color = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.height(12.dp))

                        // 3. التذييل والتوقيعات الرسمية في أسفل الصفحة
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // جهة اليمين: إعداد / مسئول الأمن
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "إعداد / مسئول الأمن",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF334155)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = adminConfig.securityOfficerName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EduBlue
                                )
                            }

                            // جهة اليسار: يعتمد / مدير عام الإدارة
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "يعتمد / مدير عام الإدارة",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF334155)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = adminConfig.directorGeneralName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EduBlue
                                )
                            }
                        }
                    }
                }
            } else {
                // حالة وجود أحداث لهذا اليوم
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "مكتب الأمن - ليوم: $dayDateText",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = EduBlue
                            )
                            Badge(containerColor = SeverityHigh) {
                                Text("${dayIncidents.size} حدث", color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        dayIncidents.forEachIndexed { idx, inc ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.background
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "${idx + 1}) ${inc.title} - ${inc.schoolName}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "الحالة: ${inc.status.displayNameAr} | الوقت: ${inc.timeString}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (inc.actionTaken.isNotBlank()) {
                                        Text(
                                            text = "الإجراء: ${inc.actionTaken}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = EduGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // خيارات التصدير والمشاركة الرسمية (Word DOCX, PDF, Print, WhatsApp, Excel)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "خيارات التصدير والمستندات الرسمية:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // 1. تصدير مستند Word (DOCX)
                    Button(
                        onClick = {
                            val docxFile = ReportExporter.generateDailyReportDocx(
                                context = context,
                                date = selectedDate,
                                incidents = incidents,
                                adminConfig = adminConfig
                            )
                            val title = if (dayIncidents.isEmpty()) "إفادة خلو أحداث Word (DOCX)" else "تقرير الأحداث Word (DOCX)"
                            ReportExporter.shareGeneratedFile(
                                context = context,
                                file = docxFile,
                                mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                title = title
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B579A)), // Word Blue
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("export_word_docx_button")
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (dayIncidents.isEmpty()) "تصدير إفادة خلو الأحداث Word (DOCX) 📄" else "تصدير تقرير الأحداث Word (DOCX) 📄",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. تصدير ملف PDF عبر PdfDocument
                    Button(
                        onClick = {
                            val pdfFile = ReportExporter.generateDailyReportPdf(
                                context = context,
                                date = selectedDate,
                                incidents = incidents,
                                adminConfig = adminConfig
                            )
                            val title = if (dayIncidents.isEmpty()) "إفادة خلو أحداث PDF" else "تقرير الأحداث PDF"
                            ReportExporter.shareGeneratedFile(
                                context = context,
                                file = pdfFile,
                                mimeType = "application/pdf",
                                title = title
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("export_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (dayIncidents.isEmpty()) "تصدير إفادة خلو الأحداث PDF 📑" else "تصدير تقرير الأحداث PDF 📑",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 3. طباعة رسمية مباشرة
                        OutlinedButton(
                            onClick = {
                                ReportExporter.exportToPdfPrint(
                                    context = context,
                                    period = ReportExporter.ReportPeriod.DAILY,
                                    incidents = incidents,
                                    adminConfig = adminConfig,
                                    selectedDate = selectedDate
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("print_report_button")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, tint = EduBlue)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("طباعة رسمية", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        }

                        // 4. مشاركة واتساب
                        Button(
                            onClick = {
                                WhatsAppHelper.shareTextToWhatsApp(context, reportText)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("share_report_whatsapp_button")
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("واتساب 🟢", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 5. تصدير Excel / CSV
                    OutlinedButton(
                        onClick = {
                            val csv = ReportExporter.exportIncidentsToCsv(dayIncidents.ifEmpty { incidents })
                            ReportExporter.shareCsvToExternal(context, csv)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("export_excel_button")
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, tint = EduGreen)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير جدول البيانات Excel / CSV", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }

            // كارت نص الإفادة المعتمد مع إمكانية النسخ
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نص الإفادة والتقرير المعتمد",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                val clip = android.content.ClipData.newPlainText("تقرير أمن سمالوط", reportText)
                                clipboard?.setPrimaryClip(clip)
                                android.widget.Toast.makeText(context, "تم نسخ التقرير إلى الحافظة", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ التقرير", tint = EduBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.background,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = reportText,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp),
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
